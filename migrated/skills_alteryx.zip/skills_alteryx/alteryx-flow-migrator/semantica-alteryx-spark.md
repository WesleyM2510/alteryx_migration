# Semântica Alteryx → Spark: Armadilhas Obrigatórias

## When to Use

Leitura obrigatória na Fase 4 (tradução) e na Fase 5 (notebooks). Alteryx e Spark divergem em pontos que **não geram erro — geram resultado errado em silêncio**. Verificar cada item ao traduzir cada tool.

## A armadilha nº 1: ordem de registros

Alteryx preserva a ordem dos registros; Spark **não garante ordem alguma**. Toda tool que depende de ordem exige chave de ordenação determinística explícita:

`Multi-Row Formula` · `Running Total` · `Sample` · `Unique` · `Record ID` · `Tile` · `First/Last` no Summarize

Sem chave determinística disponível → **PENDÊNCIA (R5)**. Não usar `monotonically_increasing_id()` como substituto e seguir adiante: ele não replica a ordem do Alteryx.

```sql
-- Unique do Alteryx mantém o PRIMEIRO registro na ordem de entrada:
SELECT * FROM (
  SELECT *,
         ROW_NUMBER() OVER (
           PARTITION BY chave_dedup
           ORDER BY <ordem_deterministica>  -- ex.: data_carga, id_origem
         ) AS rn
  FROM origem_int
) WHERE rn = 1
```

## Tool a tool

| Tool | Ponto de atenção |
|---|---|
| **Join** | Três saídas (L / J / R). Verificar **quais estão conectadas** — L e R viram anti-joins e são frequentemente esquecidas. J = INNER. Case-sensitive e sensível a espaço em branco. |
| **Union** | Config por **nome** vs por **posição** muda tudo. Campos ausentes → null. `unionByName(allowMissingColumns=True)` ou `union` conforme a config real. |
| **Unique** | Mantém o primeiro na ordem de entrada → `row_number()` particionado + ordem determinística (ver acima). |
| **Filter** | Saídas **T e F** — as duas podem estar conectadas. Null na condição cai no **F**. `!=` → `<>`. Expressão Alteryx ≠ SQL. |
| **Formula** | `IIF` → `CASE WHEN`. **`Substring` é 0-based no Alteryx e 1-based no SQL.** `IsNull` ≠ `IsEmpty` (`""` não é null). `DateTimeFormat`/`DateTimeParse` usam máscara `%Y-%m-%d`, não `yyyy-MM-dd`. |
| **Select** | Renomes + casts + deselects. `Fixed Decimal` → `decimal(p,s)`: conferir truncamento vs arredondamento. |
| **Summarize** | `Concat` (separador e ordem!) → `concat_ws` + `collect_list`. `Count` vs `CountNonNull`. `First`/`Last` dependem de ordem. |
| **Multi-Row Formula** | `Row-1:[Campo]` → `lag()`. Respeitar `Group By`. A opção para linhas inexistentes (`Null` / `0` / `Closest Valid Row`) **muda o resultado** — ler a config. |
| **Cross Tab** | → `pivot`. Alteryx **sanitiza nomes de coluna** (especiais → `_`) e ordena as colunas geradas. Replicar. |
| **Transpose** | → `stack()` / unpivot. Atenção a key fields vs data fields. |
| **Append Fields** | Cross join. Há limite de segurança configurado no Alteryx — verificar. |
| **Find Replace** | Modo append vs replace; `Case Insensitive` é opção — ler a config. |
| **Data Cleansing** | É macro: expandir em trim/null replacement/remoção de caracteres conforme os checkboxes marcados. |
| **Text to Columns** | Split em colunas **ou em linhas** (`explode`) — semânticas diferentes. |
| **Dynamic Rename/Select** | Schema dinâmico. Alto risco de divergência — documentar a decisão. |
| **Block Until Done** | Impõe ordem de execução → dependência entre notebooks. |
| **Interface tools** | Fluxo é Analytic App → parâmetros viram widgets. |

## Tipos e nomes

| Alteryx | Spark SQL |
|---|---|
| `V_String` / `V_WString` | `string` (atenção a unicode) |
| `Fixed Decimal` | `decimal(p,s)` |
| `Byte` / `Int16` / `Int32` / `Int64` | `tinyint` / `smallint` / `int` / `bigint` |
| `Bool` | `boolean` |
| `Date` / `DateTime` | `date` / `timestamp` |

- Nomes de campo com espaço ou acento (comuns em Alteryx) exigem **backticks** no SQL.
- Alteryx distingue `null` de `""`. Preservar a distinção.

## Tips

- Se a contagem bate e as somas divergem, o suspeito nº 1 é ordem de registros; o nº 2 é null em condição de filtro/join.
- Join duplicando linhas: chave não é única no lado direito — conferir com `count distinct` antes de culpar a tradução.
- Diferença pequena e sistemática em decimais: truncamento (Alteryx Fixed Decimal) vs arredondamento (cast SQL).
