---
name: alteryx-flow-migrator
description: [INATIVA — migração concluída] Referência do padrão de migração de fluxos Alteryx (.yxmd) para notebooks Databricks. NÃO acionar para migrar — o parque já foi migrado e não há novo parque a caminho. Consultada pela alteryx-flow-validator como definição do padrão que os notebooks em produção seguem: regra de quebra, nomenclatura int_/final, anotação @alteryx por ToolID, fidelidade ao .yxmd, um save por notebook. Reativar apenas se novo parque Alteryx ou outra ferramenta de ETL entrar em escopo.
---

# Skill: alteryx-flow-migrator

> ## ⛔ SKILL INATIVA — migração concluída
>
> Todos os fluxos Alteryx do projeto já foram migrados. Esta skill era a ferramenta de
> **produção** da migração; com o parque migrado e sem novo parque a caminho, ela não é mais
> executada para criar notebooks.
>
> **Mantida como referência do padrão**, não como ferramenta ativa. O conteúdo abaixo — regras
> de quebra, nomenclatura, anotação `@alteryx`, fidelidade ao `.yxmd` — descreve o padrão que os
> notebooks em produção seguem, e é consumido pela `alteryx-flow-validator` para conferir
> conformidade. Leia para **entender** o padrão; não a acione para migrar.
>
> Se um novo parque Alteryx (ou outra ferramenta de ETL) entrar em escopo, reavaliar a
> reativação.

## Escopo

Converter fluxos Alteryx (.yxmd) em notebooks Databricks.
Executar quando solicitado a migrar/transcrever fluxos Alteryx.

## Pre-requisitos

  readAssetById(assetType="file", assetId="/Workspace/Shared/Engineering/Migracao_Alteryx/AGENTS.md")

---

## Ao receber o pedido de migração

1. Pergunte: **Qual a pasta onde estão os arquivos .yxmd?**
2. Pergunte: **Qual será o prefixo do nome das tabelas?** (ex: `planejamento`, `financeiro_custos`)
3. Leia o modelo obrigatório em `/Workspace/Shared/Engineering/Migracao_Alteryx/_fluxo_modelo` — notebooks e _executor.

---

## Regras de Criação dos Notebooks

### Criação automática de diretórios

Ao receber uma pasta contendo arquivos `.yxmd`, criar automaticamente a estrutura de diretórios para cada fluxo:

1. Para **cada arquivo `.yxmd`** encontrado na pasta, criar uma subpasta com o mesmo nome do arquivo (sem a extensão `.yxmd`).
2. Dentro de cada subpasta, criar a pasta `notebooks/`.
3. Mover (ou manter referência) o `.yxmd` na subpasta correspondente.
4. Ignorar arquivos `.yxwz` (workflows wizard) — não são fluxos migráveis.

Resultado esperado:
```
<Pasta_Dominio>/
├── <Nome_Fluxo_1>/
│   ├── <Nome_Fluxo_1>.yxmd
│   ├── notebooks/
│   │   ├── 001_int_<prefixo>__<tabela_a>
│   │   ├── 002_<prefixo>__<tabela_final>
│   │   └── ...
│   └── _executor
├── <Nome_Fluxo_2>/
│   ├── <Nome_Fluxo_2>.yxmd
│   ├── notebooks/
│   │   └── ...
│   └── _executor
└── _executor_master
```

Se os `.yxmd` já estiverem soltos na raiz da pasta (sem subpastas), criar as subpastas e organizar.

### Regra de quebra (4.01)

Criar notebooks separados **apenas** quando existir persistência reutilizada por notebook posterior:
- **Correto:** `001` gera `int_financeiro__calculo` → `002` gera `int_financeiro__deducoes` → `003` gera `financeiro__fechamento` (depende de 001 e 002)
- **Incorreto:** `001_filter` → `002_sort` → `003_join` (sem persistência intermediária necessária)

### Fidelidade total ao Alteryx (4.02)

Na seção de Fluxo **não invente nada** que não exista na lógica do Alteryx. Transcrever exatamente como está no .yxmd. O que não mapear 1:1 → registrar como pendência.

### Spark SQL obrigatório (4.03)

Escrever tudo que for possível em Spark SQL:
```python
df = spark.sql("""
    SELECT col1, col2
    FROM fonte_int
    WHERE status = 'A'
""")
df.createOrReplaceTempView("df")
```

### Proibição de DDL temporária em SQL (4.04)

Não escrever `CREATE [OR REPLACE] [GLOBAL] TEMP[ORARY] VIEW`/`TABLE` dentro de `spark.sql()` — em nenhuma variação de sintaxe.

O registro de view de sessão é feito **pela API DataFrame**, que é o padrão do projeto:

```python
df = spark.sql("""SELECT ...""")
df.createOrReplaceTempView("<alias>")   # permitido e obrigatório
```

Motivo: manter o encadeamento visível em Python e cada bloco ancorado em uma atribuição `df = spark.sql(...)`, que é o que torna a anotação `@alteryx tool_id=` grepável. DDL dentro da string esconde o passo e quebra a rastreabilidade por ToolID.

`createGlobalTempView` é proibido — escopo global vaza entre notebooks do mesmo cluster.

### Modelo obrigatório (4.05 / 4.06)

Seguir a estrutura de `/Workspace/Shared/Engineering/Migracao_Alteryx/_fluxo_modelo`. Todo notebook deve ter:

```
Célula 1:  table = '<prefixo>__<nome_tabela>'
Célula 2:  %md ### Imports/Parametros/Dados
Célula 3:  %run /Workspace/Shared/Engineering/Migracao_Alteryx/_libs/_setup
Célula 4:  names = [...] + args = utl.widgets_start(names=names)
           ##comment: somente parametros necessarios ao fluxo
Célula 5:  **[OBRIGATÓRIO]** Fontes — todas as leituras em um único lugar
           ##comment: celula contendo todas as fontes utilizadas
           ⛔ Ausência desta célula invalida a migração.
Célula 6:  %md ### Fluxo
Célula 7+: Lógica de transformação (spark.sql)
Célula N-1: %md ### Save
Célula N:  sv.save(df=df, tabela=table)
```

Observar todas as tags `##comment:` no modelo — replicar conforme necessário.

### ⚠️ Célula de Fontes — OBRIGATÓRIO (4.05.1)

A **Célula 5 (Fontes)** é obrigatória em **todo notebook**. Sua ausência invalida a migração.

**Posição:** imediatamente após a célula de parâmetros (Célula 4), antes de `%md ### Fluxo`.

**Conteúdo mínimo — Delta table:**
```python
##comment: celula contendo todas as fontes utilizadas
# @alteryx tool_id=XX plugin=... caption="..."
# Lineage: <caminho_origem>
df_fonte = spark.table("`dtlk-sandbox`.micracao_alteryx.<tabela>")
df_fonte.createOrReplaceTempView("<alias>")
```

**Para fontes pendentes (arquivo sem caminho definido):**
```python
##comment: celula contendo todas as fontes utilizadas
# TODO: definir caminho do arquivo no Volume
# df_fonte = spark.read.csv("/Volumes/.../arquivo.csv", header=True, sep=";")
# df_fonte.createOrReplaceTempView("<alias>")
print("[FONTES] Aguardando caminho da fonte.")
```

**Checklist obrigatório antes de finalizar qualquer migração:**
- [ ] O notebook possui a Célula 5 com `##comment: celula contendo todas as fontes utilizadas`?
- [ ] Todas as fontes (Delta tables, CSVs, Excel) estão declaradas nessa célula?
- [ ] Cada fonte tem anotação `# @alteryx tool_id=XX ...` quando aplicável?
- [ ] Fontes de arquivo possuem caminho completo original do Alteryx (regra 4.05.2)?

### ⚠️ Bloco de comentários de origem — OBRIGATÓRIO (4.05.2)

**TODA fonte na Célula 5 DEVE ter o bloco de 3 linhas de comentários de origem.** A ausência de qualquer uma das 3 linhas invalida a migração.

⛔ **Ausência do bloco de origem ou caminho incompleto = migração inválida.**

**Formato obrigatório — 3 linhas para CADA fonte:**

```
# @alteryx tool_id=<ID> plugin=<Plugin>
# ORIGEM ALTERYX: <caminho_completo_exato_do_yxmd>
# TIPO: <tipo_fonte> | STATUS LAKE: <SIM|NÃO|VERIFICAR> [-> tabela_lake se SIM]
```

**Regras do caminho (linha `# ORIGEM ALTERYX:`):**

- Para **ARQUIVOS (Excel/CSV/TXT)**: copiar o caminho EXATAMENTE como aparece na tag `<File>` do XML do .yxmd
  - Network shares: `\\servidor\share\pasta\arquivo.xlsx`
  - Drives mapeados: `Z:\pasta\subpasta\arquivo.xlsx`
  - Excel com sheet: `caminho\arquivo.xlsx|||NomeSheet$`
  - Wildcard/dinâmico: `\\servidor\pasta\Pattern*.xlsx` (extraído de `<Directory>` + `<FileSpec>`)
- Para **SQL Server/ODBC**: `odbc:DSN=<dsn> -> <TABELA>` ou `<servidor>.<database>.<tabela>`
- Para **Lineage interna** (Delta table de outro notebook): `Lineage interna -> notebook <nome> do <fluxo>`
- Para **TextInput** (dados inline no .yxmd): `[TextInput inline - <N> registros hardcoded no .yxmd]`
- Para **caminho dinâmico** (macro): `[CAMINHO DINÂMICO - macro tool_id=XX gera path em runtime]`

**NÃO abreviar, NÃO omitir partes do caminho, NÃO substituir por descrições genéricas.**

**Exemplos CORRETOS:**
```python
# @alteryx tool_id=34 plugin=AlteryxBasePluginsGui.Directory.Directory + DynamicInput
# ORIGEM ALTERYX: \\swap629\operacoes_varejo$\Controles\Bases Restrição\2026\Restrições*.xlsx|||Planilha1$
# TIPO: Excel (dinâmico - arquivo mais recente da pasta) | STATUS LAKE: NÃO
df_fonte = spark.sql("SELECT * FROM ...")
df_fonte.createOrReplaceTempView("fonte")

# @alteryx tool_id=21 plugin=AlteryxBasePluginsGui.DbFileInput.DbFileInput
# ORIGEM ALTERYX: \\swap629\GEFOC$\01_Indicadores Financeiros\REQUISIÇÕES\Filas da Mesa.xlsx|||Planilha1$
# TIPO: Excel | STATUS LAKE: NÃO
df_filas = spark.sql("SELECT * FROM ...")
df_filas.createOrReplaceTempView("df_filas")
```

**Exemplos de VIOLAÇÃO (INCORRETO):**
```python
# Fonte 1: Restrições xlsx (carregado pelo _save-files)        ← ERRADO: sem caminho, sem tool_id
# Fonte: Grupo Produto (carregado pelo _save-files)            ← ERRADO: descrição genérica
# ORIGEM ALTERYX: arquivo de controle                          ← ERRADO: não é caminho
```

**Checklist 4.05.2:**
- [ ] Cada fonte tem `# @alteryx tool_id=XX plugin=...`?
- [ ] Cada fonte tem `# ORIGEM ALTERYX:` com o caminho COMPLETO (copiado da tag File/Directory do XML)?
- [ ] Cada fonte tem `# TIPO: ... | STATUS LAKE: ...`?

### Nomenclatura de tabelas (4.07)

- **Intermediárias** (usadas só internamente no fluxo): `int_<prefixo>__<nome>`
- **Finais** (resultado do fluxo): `<prefixo>__<nome>`

### Nomenclatura de notebooks (4.08)

```
<sequencia>_<nome_da_tabela_do_save>
```
Exemplos: `001_int_planejamento__base_motor`, `002_planejamento__motor_saques`

### Tipo de carga (4.09)

Analisar a lógica do Alteryx e identificar se a carga é append, overwrite, delete+insert, etc. Criar uma **última célula comentada** documentando a lógica identificada:

```python
# ===========================================================================
# TIPO DE CARGA IDENTIFICADO:
# - Modo: Delete anterior (ANO/MES) + Insert
# - Evidência: Tool "Run Command" executa DELETE antes do Output
# - Ação manual necessária: implementar lógica de delete
# ===========================================================================
```

### Lineage / substituição de fontes (4.10)

Se o .yxmd lê `swap1478_pl.dbo.<tabela>`, verificar se algum notebook de **qualquer outro fluxo** já salva essa tabela no lake. Se sim, substituir pela tabela do lake:
- `swap1478_pl.dbo.tabela_a` → `` `dtlk-sandbox`.micracao_alteryx.<prefixo>__tabela_a ``

Consultar os mapeamentos confirmados em AGENTS.md.

### Um save por notebook (4.11)

**Cada `sv.save()` deve estar em um notebook separado.** Um notebook = uma tabela persistida.

**Exceção única:** múltiplas tabelas intermediárias podem estar no mesmo notebook **se e somente se** TODAS as condições abaixo forem verdadeiras:
1. As intermediárias são SELECTs simples (filtros/projeções sobre a mesma base processada)
2. Geram **uma única tabela final** no mesmo notebook (as intermediárias servem apenas como steps para chegar à final)
3. Nenhuma das intermediárias é consumida por outro notebook como fonte

**Se o fluxo Alteryx tiver múltiplos outputs independentes** (ex: 3 filtros que geram 3 arquivos diferentes), criar um notebook para cada output:
- `001_<prefixo>__output_a` — processa e salva output A
- `002_<prefixo>__output_b` — processa e salva output B
- `003_<prefixo>__output_c` — processa e salva output C

Cada notebook pode compartilhar as mesmas fontes (lidas novamente ou via tabela intermediária persistida por notebook anterior).

**Exemplo prático (caso Mapa de Contingências):**
- Fluxo Alteryx: 1 fonte → processamento comum → 3 filtros → 3 outputs independentes
- Resultado correto:
  ```
  001_int_juridico__mapa_contingencias_base   ← processamento comum, persiste base
  002_juridico__mapa_contingencias_qtd_causa  ← filtra e salva output 1
  003_juridico__mapa_contingencias_tkt_medio  ← filtra e salva output 2
  004_juridico__mapa_contingencias_provisao   ← filtra e salva output 3
  ```

---

### Criação do _executor (5)

Criar notebook `_executor` conforme `/Workspace/Shared/Engineering/Migracao_Alteryx/_fluxo_modelo/_executor`:

```python
# Célula 1
%run /Workspace/Shared/Engineering/Migracao_Alteryx/_libs/_setup

# Célula 2
##comment: coloque os parametros necessarios solicitados nos notebooks
names = ["pr_ano", "pr_mes", "pr_versao"]
args = utl.widgets_start(names=names)

# Célula 3
import os
BASE_PATH = os.getcwd()
PARAMS = {
    "pr_ano": args.get("pr_ano"),
    "pr_mes": args.get("pr_mes"),
    "pr_versao": args.get("pr_versao"),
}

# Célula 4
notebooks = [
    f"{BASE_PATH}/notebooks/001_int_<prefixo>__<tabela_a>",
    f"{BASE_PATH}/notebooks/002_<prefixo>__<tabela_final>",
]

# Célula 5
%run /Shared/Engineering/Migracao_Alteryx/_libs/_setup_executor
```

Os parâmetros do executor devem ser **exatamente os mesmos** solicitados pelos notebooks.

---

## Parâmetros

Não existem parâmetros padrão fixos. Os parâmetros devem ser **identificados a partir do fluxo Alteryx** durante a análise do .yxmd (ex: variáveis de entrada, filtros temporais, conexões parametrizadas). Cada fluxo define seus próprios parâmetros conforme necessidade.

---

## Reference Files

- [processo.md](processo.md) — Fases detalhadas de execução
- [semantica-alteryx-spark.md](semantica-alteryx-spark.md) — Armadilhas de tradução tool-a-tool (obrigatório durante tradução)

---

---

---

## [OBRIGATÓRIO] Documentação de Fontes de Origem (4.12)

Toda migração DEVE documentar as fontes de origem originais do Alteryx:
- Na **Célula 5 (Fontes)** do notebook com comentários `# ORIGEM ALTERYX:`
- Na **tabela Delta** `dtlk-sandbox`.micracao_alteryx.fontes_origem via INSERT (ÚNICO controle centralizado)

> ⚠️ **O arquivo `fontes_origem.md` NÃO é mais mantido.** A tabela Delta é a única fonte de verdade para controle de fontes.

### 4.12.1 — Anotação na Célula 5

Cada fonte DEVE conter o bloco de 3 linhas conforme regra 4.05.2:
```python
# @alteryx tool_id=XX plugin=AlteryxBasePluginsGui.DbFileInput.DbFileInput
# ORIGEM ALTERYX: <caminho completo original copiado EXATAMENTE da tag File do .yxmd>
# TIPO: Excel | STATUS LAKE: NÃO
df_fonte = spark.sql("SELECT * FROM ...")
df_fonte.createOrReplaceTempView("fonte")
```

Para fontes de banco:
```python
# @alteryx tool_id=XX plugin=AlteryxBasePluginsGui.DbFileInput.DbFileInput
# ORIGEM ALTERYX: odbc:DSN=PL -> CADASTRO_HIE_PRODUTOS
# TIPO: SQL Server | STATUS LAKE: SIM -> dtlk-sandbox.micracao_alteryx.planejamento__cadastro_subcanais
df = spark.sql("SELECT * FROM `dtlk-sandbox`.micracao_alteryx.planejamento__cadastro_subcanais")
df.createOrReplaceTempView("cadastro")
```

⛔ **Para fontes de ARQUIVO (Excel/CSV/TXT):** o caminho DEVE ser exato do .yxmd (ver regra 4.05.2). Descrições genéricas como "Restrições xlsx" ou "arquivo de controle" são PROIBIDAS.

### 4.12.2 — Registro na tabela `fontes_origem` [OBRIGATÓRIO]

Critério de `existe_lake`, schema, verificação de existência, verificação de duplicata,
INSERT, UPDATE e checklist: **[../_shared/fontes-origem.md](../_shared/fontes-origem.md)**.

Regra canônica única — não reescrever o conteúdo aqui. Ao migrar um fluxo:

1. Verificar existência no lake para cada fonte (§3 do arquivo compartilhado)
2. Verificar duplicata `fluxo` + `tool_id` (§4)
3. Executar o INSERT (§5)

⛔ Migração sem INSERT na tabela `fontes_origem` = migração inválida.

### 4.12.3 — Atualização contínua

Mencionou fonte + lake na mesma conversa → atualizar a tabela. Templates de UPDATE em
[../_shared/fontes-origem.md](../_shared/fontes-origem.md) §6.


---

## Caminhos Fixos do Projeto

| Referência | Caminho |
|---|---|
| Modelo de notebook | `/Workspace/Shared/Engineering/Migracao_Alteryx/_fluxo_modelo` |
| Libs (setup) | `/Workspace/Shared/Engineering/Migracao_Alteryx/_libs/_setup` |
| Libs (executor) | `/Shared/Engineering/Migracao_Alteryx/_libs/_setup_executor` |
| Catálogo destino | `` `dtlk-sandbox`.micracao_alteryx `` |
| Função de save | `sv.save(df=df, tabela=table)` |
| Função de widgets | `utl.widgets_start(names=names)` |
| Tabela de fontes | `` `dtlk-sandbox`.micracao_alteryx.fontes_origem `` |
| Regra canônica de fontes | `skills/_shared/fontes-origem.md` |
| Dashboard de fontes | Fontes de Origem — Migração Alteryx |

