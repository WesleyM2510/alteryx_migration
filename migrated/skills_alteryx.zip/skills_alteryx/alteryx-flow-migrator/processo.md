# Processo de Migração — Fases 0 a 8

## Glossário

| Termo | Definição |
|---|---|
| **RAIZ_PROJETO** | Pasta que contém todas as pastas de fluxo. Onde ficam o executor master e o levantamento consolidado. |
| **PASTA_FLUXO** | Pasta de um fluxo, com o mesmo nome do `.yxmd`. Contém o `.yxmd`, `scripts/`, `notebooks/` e os artefatos de rastreabilidade. |
| **SCRIPT** | `.py` do tipo FILE (não notebook) em `PASTA_FLUXO/scripts/`. Tradução as-is; artefato de auditoria. |
| **NOTEBOOK** | Notebook Databricks em `PASTA_FLUXO/notebooks/`. Executável de produção, autocontido. |
| **EXECUTOR_FILHO** | Notebook `_executor` em `PASTA_FLUXO/` (irmão de `notebooks/`, não dentro dela) que orquestra os notebooks do fluxo. |
| **EXECUTOR_MASTER** | Notebook em `RAIZ_PROJETO` que chama todos os executores filhos. |
| **NOTEBOOK_DE_INGESTAO** | Notebook externo à `PASTA_FLUXO`, responsável por toda leitura de arquivos. |
| **LEVANTAMENTO_DE_FONTES** | Notebook que inventaria fontes (entrada/intermediária/saída) + disponibilidade no Unity Catalog, no formato de `TEMPLATE_LEVANTAMENTO_FONTES`. |
| **TOOL ATIVA** | Nó não desabilitado e fora de container desabilitado (herança recursiva). |

---

## Fase 0 — Absorver os padrões (bloqueante)

1. Ler integralmente: `PADRAO_SCRIPTS`, `PADRAO_NOTEBOOKS`, `PADRAO_EXECUTOR_FILHO`, `EXECUTOR_MASTER`, `PADRAO_NOTEBOOK_INGESTAO`, `TEMPLATE_LEVANTAMENTO_FONTES`.
2. Produzir `padrao_observado.md` descrevendo o que **de fato** foi observado: estrutura de células, cabeçalhos, convenções de nome, nomenclatura de tabelas, forma das queries, widgets/parâmetros, tratamento de erro, logging, colunas do template de fontes.
3. Só avançar após imprimir esse resumo. **Não inferir o padrão — lê-lo.**

## Fase 1 — Estrutura de pastas

Criar a árvore descrita no SKILL.md dentro de `RAIZ_PROJETO`, aplicando R1. Imprimir a árvore criada.

## Fase 2 — Parsing do XML e inventário de tools

1. Ler o `.yxmd` como XML.
2. Contar o total de nós (`<Node ToolID=...>`).
3. Produzir `inventario_tools.md` com **uma linha por nó**, inclusive os ignorados:

| ToolID | Plugin | Caption/Annotation | Container pai | Ativa? | Motivo (se inativa) | Entradas (ToolID:porta) | Saídas (ToolID:porta) |
|---|---|---|---|---|---|---|---|

4. **Conferência obrigatória:** `nós no XML == linhas no inventário`. Divergência = parar e investigar.
5. Reconstruir o DAG a partir de `<Connections>` (R9) e registrar a ordem topológica.
6. **Macros (`.yxmc`)**: listar cada uma, resolver o conteúdo recursivamente e tratar as tools internas como parte do fluxo. Batch/Iterative macros: se a semântica não puder ser resolvida com certeza, `PENDENCIAS.md` (R5).

## Fase 3 — Levantamento de fontes + Unity Catalog

Produzir `levantamento_fontes_<NomeDoFluxo>` **no formato exato de `TEMPLATE_LEVANTAMENTO_FONTES`** (mesmas colunas, mesma ordem, mesmos rótulos):

1. Classificar cada fonte: **entrada**, **intermediária** ou **saída**.
2. Para cada uma: identificador completo (`catalogo.schema.objeto` ou caminho), ToolID de origem, tipo (table/view/volume/arquivo), checagem de existência no UC.
3. Checagem real: `information_schema.tables` / `SHOW TABLES` / `DESCRIBE TABLE` → registrar `existe = S/N`. Não presumir existência pelo nome.
4. Registrar o flag agregado `todas_as_fontes_de_entrada_disponiveis = S/N`.

## Fase 4 — Tradução para SCRIPT (FILES)

1. Traduzir **toda** a lógica das tools ativas para Python com transformação em SQL (`spark.sql("""..."""`). Python orquestra; a regra de negócio vive no SQL.
2. Seguir `padrao_observado.md`: organização, nomenclatura, tecnologia.
3. **Organização**: múltiplos arquivos por bloco lógico coerente (estágio/ramo do DAG/domínio). Um arquivo por tool = fragmentação; tudo num arquivo = monolito. Nome por função, prefixo numérico refletindo a ordem topológica.
4. **Anotação `@alteryx` obrigatória por bloco** (ver Pattern 2 do SKILL.md). Formato fixo: `@alteryx tool_id=<ids> plugin=<plugin> caption="<texto>"`.
5. Aplicar [semantica-alteryx-spark.md](semantica-alteryx-spark.md) sem exceção.
6. Aplicar R2 e R3 ao gravar.

## Fase 5 — Notebooks

1. Materializar a **mesma** lógica em notebooks em `PASTA_FLUXO/notebooks/`, no padrão de `PADRAO_NOTEBOOKS`. Aplicar R4.
2. Primeira célula (markdown): fluxo de origem, escopo, tabelas lidas, tabelas escritas, ToolIDs cobertos.
3. **Seção de origens única no topo**: todas as leituras, incluindo dependências de tabelas produzidas por notebooks anteriores, declaradas explicitamente. Nenhuma leitura no meio da lógica.
4. **Nomenclatura**: intermediárias com **prefixo** `int_<prefixo>__<nome>`; finais `<prefixo>__<nome>`, sem `int_`. (Regra 9 do AGENTS.md — o prefixo `int_`, nunca sufixo `_int`.)
5. **Leitura de arquivos**: Input Data de filesystem não entra no notebook do fluxo — vai para o `NOTEBOOK_DE_INGESTAO` externo, no padrão de `PADRAO_NOTEBOOK_INGESTAO`. O notebook do fluxo consome a tabela resultante e declara a dependência na seção de origens.
6. Repetir a anotação `@alteryx` por bloco/célula.

## Fase 6 — Executores e parâmetros

1. Criar o `_executor` filho em `PASTA_FLUXO/` — irmão de `notebooks/`, conforme a árvore do AGENTS.md e o caminho usado pelo `_executor_master` (`{BASE_PATH}/<Fluxo>/_executor`). No padrão de `PADRAO_EXECUTOR_FILHO`, chamando os notebooks na ordem topológica.
2. Declarar no filho todos os parâmetros necessários no dict `PARAMS`, repassados com `args.get("pr_<nome>")`. Nos notebooks, a captura é `names = [...]` + `args = utl.widgets_start(names=names)` — não usar `dbutils.widgets` diretamente.
3. Editar o `EXECUTOR_MASTER` para chamar o filho **passando esses parâmetros**. Reler o master após a edição e imprimir as linhas de chamada como prova.
4. **Conferência**: todo filho tem chamada no master; todo parâmetro do filho é fornecido pelo master.

## Fase 7 — Mapa de regras (matriz de cobertura)

Produzir `mapa_de_regras.md`:

| ToolID | Plugin | Regra (uma frase) | Expressão/config original | Implementado em (arquivo:linha) | Notebook (célula) | Status |
|---|---|---|---|---|---|---|

Conferências obrigatórias:
- `tools ativas no inventário == linhas no mapa`
- toda linha com `Implementado em` **e** `Notebook` preenchidos com referência verificável
- `Status ∈ {OK, PENDENTE}`; todo `PENDENTE` tem entrada em `PENDENCIAS.md`
- nenhuma tool ativa sem cobertura; nenhum bloco de código sem tool de origem

Imprimir contadores: `ativas / mapeadas / OK / PENDENTE`.

## Fase 8 — Consolidado na raiz

1. Criar/atualizar `levantamento_fontes_consolidado` em `RAIZ_PROJETO`: união das fontes de todos os fluxos, mesmo template, com coluna adicional identificando o fluxo de origem.
2. Deduplicar fontes compartilhadas mantendo rastreabilidade de quais fluxos as consomem.
3. Produzir `RELATORIO_MIGRACAO.md` no formato definido em [alteryx-flow-validator/SKILL.md](../alteryx-flow-validator/SKILL.md). Concluída a Fase 8, o fluxo entra na `alteryx-flow-validator`; só após veredito APROVADO ou APROVADO COM RESSALVAS ele segue para a `alteryx-translation-validator`.
