---
name: alteryx-flow-validator
description: Ative para auditar a CONFORMIDADE ESTRUTURAL de um fluxo Alteryx migrado — se os artefatos existem, se a cobertura do .yxmd é completa (toda tool mapeada, nada inventado), se nomenclatura, parâmetros e proibições seguem o padrão. Gatilhos: 'valida esse fluxo', 'confere se a migração está correta', 'esse notebook segue o padrão?', 'audita a estrutura', após qualquer migração ou correção estrutural. Emite veredito APROVADO/RESSALVAS/REPROVADO por fluxo; REPROVADO bloqueia a entrada na alteryx-translation-validator. Cobre R2, R3, R4, R5, R8, R9, R10. Complementa a translation-validator (que valida dados, não estrutura).
---

# Skill: alteryx-flow-validator

## Escopo

Auditar a **conformidade estrutural** de um fluxo migrado: os artefatos existem, a cobertura do XML é completa, a nomenclatura e os contratos seguem o padrão do projeto, e nenhuma proibição foi violada.

Complementa — não substitui — a `alteryx-translation-validator`:

| Skill | Pergunta que responde |
|---|---|
| `alteryx-flow-validator` | O código migrado **segue os padrões do projeto** e cobre todo o `.yxmd`? |
| `alteryx-translation-validator` | O código migrado **produz o mesmo resultado** que o Alteryx? |

Entrega um veredito por fluxo (APROVADO | APROVADO COM RESSALVAS | REPROVADO), com cada achado localizado por arquivo:linha ou notebook:célula.

## Encadeamento

```
alteryx-flow-migrator  →  alteryx-flow-validator  →  alteryx-translation-validator
                              (esta skill)
```

**REPROVADO aqui bloqueia a entrada na `alteryx-translation-validator`.** Não faz sentido reconciliar dado de um fluxo cuja cobertura do XML está incompleta: a divergência encontrada seria atribuída à tradução quando a causa é tool não migrada.

Executar após qualquer migração, e novamente após qualquer correção estrutural.

## Pre-requisitos

  readAssetById(assetType="file", assetId="/Workspace/Shared/Engineering/Migracao_Alteryx/AGENTS.md")

Ler também, do fluxo em validação:
- O `.yxmd` original
- `inventario_tools.md`, `mapa_de_regras.md`, `padrao_observado.md`, `levantamento_fontes_<fluxo>`
- `PENDENCIAS.md`, se existir
- Regra canônica de fontes: [../_shared/fontes-origem.md](../_shared/fontes-origem.md)

## Ao receber o pedido de validação

Perguntar:

1. **Qual fluxo (pasta) validar?**
2. **É primeira validação ou revalidação após correção?** Na revalidação, reentrar na fase que falhou — não repetir as anteriores já aprovadas.
3. **Há exceção de padrão previamente aceita para este fluxo?** (ex.: exceção 4.11 de múltiplos saves, com aceite registrado)

---

## Fases

Aplicar [checklist-estrutural.md](checklist-estrutural.md), que traz cada check com comando de verificação e formato de evidência.

**Não avançar de fase com a anterior em ERRO** nas fases bloqueantes (A e B). Corrigir e reentrar.

### Fase A — Inventário de artefatos (bloqueante)

Os artefatos da migração existem e não estão vazios: `scripts/`, `notebooks/`, `_executor`, `padrao_observado.md`, `inventario_tools.md`, `levantamento_fontes_<fluxo>`, `mapa_de_regras.md`, `PENDENCIAS.md` quando aplicável. Inclui R3 — nada de arquivo com 0 bytes ou `pass`/`TODO` no lugar da lógica.

Falha aqui não é "um check errado": é migração incompleta. **REPROVADO imediato**, sem seguir para B.

### Fase B — Cobertura e rastreabilidade (bloqueante)

O núcleo de R5, nos dois sentidos:

- **Nada foi perdido** — nós no XML == linhas no inventário; tools ativas == linhas no mapa de regras
- **Nada foi inventado** — todo bloco de código tem ToolID de origem que existe no inventário

Inclui R8 (desabilitado registrado com motivo, herança recursiva de container) e R9 (DAG vindo de `<Connections>`, não do layout do canvas). As referências `arquivo:linha` e `notebook:célula` do mapa são conferidas por amostragem, não presumidas.

### Fase C — Estrutura e nomenclatura

Prefixo `int_` nas intermediárias, finais sem ele, numeração sequencial dos notebooks, correspondência entre nome do notebook e tabela do `sv.save()`, regra de quebra (4.01), um save por notebook (4.11) e estrutura do `_fluxo_modelo`.

### Fase D — Contratos: parâmetros e fontes

Duas interfaces declaradas que precisam casar dos dois lados.

**Parâmetros** — nomes idênticos entre notebooks, `_executor` e `_executor_master`; padrão `pr_<nome>`; aspas e zero-pad na interpolação em SQL.

**Fontes** — anotação na célula de Fontes, registro em `fontes_origem` sem duplicata, `existe_lake` com valor válido e verificado, e correspondência com os inputs reais do `.yxmd`.

### Fase E — Código e proibições

R2 (scripts são FILES), R4 (notebook não chama script), DDL de temporária em SQL, fidelidade ao `.yxmd`, colunas contra o schema real, substituição de fontes por lineage, tipo de carga documentado e R10 (idempotência da carga).

### Fase F — Relatório e veredito

Gravar `PASTA_FLUXO/validacao/relatorio_estrutural.md` no formato abaixo.

---

## Critérios de veredito

- **APROVADO** — nenhum ERRO em nenhuma fase.
- **APROVADO COM RESSALVAS** — apenas AVISOs, cada um com causa nomeada e aceite explícito do usuário registrado no relatório.
- **REPROVADO** — qualquer ERRO não resolvido, ou qualquer falha nas fases A e B.

Níveis:

| Nível | Significado |
|---|---|
| `OK` | Regra atendida, com evidência |
| `AVISO` | Desvio que não quebra o padrão mas merece decisão (ex.: intermediária órfã, DataFrame API sem justificativa) |
| `ERRO` | Violação de regra obrigatória — corrigir |
| `AMBIGUO` | O padrão do projeto se contradiz; não decidir sozinho, escalar |
| `N/A` | Condição de aplicação não existe neste fluxo — dizer por quê |

---

## Formato do Relatório

```text
=== RELATÓRIO DE VALIDAÇÃO ESTRUTURAL ===
Fluxo: <nome>  |  Data: <data>  |  Validação: inicial | revalidação (fase <X>)
Exceções aceitas: <lista ou "nenhuma">

FASE A — INVENTÁRIO DE ARTEFATOS
[OK]   A.1-A.9  todos os artefatos presentes
[ERRO] A.10     scripts/03_agregacoes.py com 0 bytes

FASE B — COBERTURA E RASTREABILIDADE
[OK]   B.1  62 nós no XML == 62 linhas no inventário
[ERRO] B.3  47 tools ativas x 44 linhas no mapa | faltam tool_id 18, 31, 52
[OK]   B.5  amostra de 10 referências conferida

FASE C — ESTRUTURA E NOMENCLATURA
[AVISO] C.10  002 tem 2 sv.save() | avaliar exceção 4.11 | notebooks/002_... células 8 e 11

FASE D — CONTRATOS
[OK]   D.1.4  parâmetros idênticos entre notebooks e _executor
[ERRO] D.2.8  3 registros com existe_lake='PARCIAL' | fontes_origem

FASE E — CÓDIGO E PROIBIÇÕES
[ERRO] E.3  CREATE OR REPLACE TEMPORARY VIEW | notebooks/001_... célula 4

VEREDITO: REPROVADO
Resumo: 41 checks | 33 ok | 2 avisos | 5 erros | 1 n/a
Bloqueia entrada na translation-validator: SIM

Próximos passos (ordem de correção):
1. B.3 — mapear tool_id 18, 31, 52 (bloqueante)
2. A.10 — regravar 03_agregacoes.py
3. E.3 — trocar por df.createOrReplaceTempView()
4. D.2.8 — reclassificar PARCIAL
```

---

## Encerramento obrigatório

Captura de descobertas conforme a regra canônica **[../_shared/loop-feedback.md](../_shared/loop-feedback.md)**:

1. **Violação estrutural recorrente** → proposta com tag `[estrutura]`, avaliada pelos três critérios antes de encaminhar ao AGENTS.md.
2. **Ambiguidade do padrão** (`[AMBIGUO]`) → proposta com tag `[ambiguo]`, com as duas referências conflitantes, escalada para o dono de triagem. **Nunca resolver em silêncio:** a próxima execução escolheria a outra leitura e o comportamento viraria não determinístico. Este é o mecanismo que evita drift do tipo `PARCIAL`, `TEMP VIEW` e `int_` × `_int`.
3. **Pendência sem resolução** → `PENDENCIAS.md`, com o check que falhou e a pergunta em aberto.
4. Se APROVADO ou APROVADO COM RESSALVAS → liberar a entrada na `alteryx-translation-validator`.

---

## Reference Files

- [checklist-estrutural.md](checklist-estrutural.md) — catálogo completo dos checks das Fases A–E, com comandos de verificação
- [../_shared/fontes-origem.md](../_shared/fontes-origem.md) — regra canônica de fontes de origem

## Caminhos e Convenções

| Referência | Valor |
|---|---|
| Relatório | `PASTA_FLUXO/validacao/relatorio_estrutural.md` |
| Executor filho | `PASTA_FLUXO/_executor` — irmão de `notebooks/`, não dentro dela |
| Intermediárias | `int_<prefixo>__<nome>` — prefixo, nunca sufixo `_int` |
| Finais | `<prefixo>__<nome>` |
| Notebooks | `<sequencia>_<nome_da_tabela_do_save>` |
| Parâmetros | `pr_<nome>`, capturados com `utl.widgets_start(names=names)` |
