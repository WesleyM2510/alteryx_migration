# Checklist Estrutural — Catálogo de Verificações

## When to Use

Fases A–E da `alteryx-flow-validator`. Cada check tem comando de verificação e formato de evidência. O `SKILL.md` define as fases e o veredito; este arquivo define **o que exatamente se verifica e como se prova**.

## Formato de evidência

Todo check registra `[OK]` / `[AVISO]` / `[ERRO]` **com referência verificável**:

```
[OK]   B.3  mapa_de_regras cobre 47/47 tools ativas          | mapa_de_regras.md
[ERRO] C.2  002 salva planejamento__base, nome diz cartoes   | notebooks/002_... célula 1
[AVISO] E.4 bloco em DataFrame API sem justificativa          | notebooks/001_... célula 6
```

Check sem referência = check não executado. Marcar `[N/A]` só quando a condição de aplicação não existe (ex.: fluxo sem tabela intermediária), e dizer por quê.

---

# Fase A — Inventário de artefatos

Sem artefato não há o que validar. Falha aqui é bloqueante: pare e reporte.

| # | Check | Como verificar |
|---|---|---|
| A.1 | `PASTA_FLUXO` existe e contém o `.yxmd` original | listar diretório |
| A.2 | `scripts/` existe e não está vazia | listar |
| A.3 | `notebooks/` existe e não está vazia | listar |
| A.4 | `_executor` existe em `PASTA_FLUXO/` — irmão de `notebooks/`, não dentro dela | listar |
| A.5 | `padrao_observado.md` existe (Fase 0 do migrator, R7) | listar |
| A.6 | `inventario_tools.md` existe | listar |
| A.7 | `levantamento_fontes_<NomeDoFluxo>` existe | listar |
| A.8 | `mapa_de_regras.md` existe | listar |
| A.9 | `PENDENCIAS.md` existe se houver qualquer `Status = PENDENTE` no mapa | cruzar A.8 |
| A.10 | **R3** — nenhum arquivo de 0 bytes em `scripts/` ou `notebooks/` | `find . -size 0` |
| A.11 | **R3** — nenhum `TODO`, `FIXME` ou `pass` no lugar de lógica | grep abaixo |

```bash
find PASTA_FLUXO/scripts PASTA_FLUXO/notebooks -type f -size 0
grep -rnE "^\s*(pass|\.\.\.)\s*$|TODO|FIXME" PASTA_FLUXO/scripts PASTA_FLUXO/notebooks
```

⛔ Qualquer ERRO em A = **REPROVADO imediato**. Não seguir para B.

---

# Fase B — Cobertura e rastreabilidade

O núcleo de R5: tudo que existe no XML foi mapeado, e tudo que existe no código veio do XML. Falha aqui é bloqueante.

| # | Check | Critério |
|---|---|---|
| B.1 | Nós no XML == linhas no `inventario_tools.md` | contagem exata; divergência = ERRO |
| B.2 | **R8** — tools desabilitadas registradas com motivo, incluindo herança recursiva de container | toda linha inativa tem `Motivo` preenchido |
| B.3 | Tools **ativas** no inventário == linhas no `mapa_de_regras.md` | contagem exata |
| B.4 | Toda linha do mapa tem `Implementado em (arquivo:linha)` **e** `Notebook (célula)` preenchidos | nenhum vazio |
| B.5 | As referências do mapa existem de fato | abrir por amostragem: mínimo 20% das linhas, ou 10, o que for maior |
| B.6 | `Status ∈ {OK, PENDENTE}` | nenhum outro valor |
| B.7 | Todo `PENDENTE` tem entrada em `PENDENCIAS.md` com ToolID, motivo e pergunta em aberto | cruzar |
| B.8 | Anotação `@alteryx` presente em todo bloco de `scripts/` e `notebooks/` | grep abaixo |
| B.9 | Nenhum bloco de código sem tool de origem | inverso de B.3 — bloco anotado com ToolID que não existe no inventário = ERRO |
| B.10 | **R9** — o DAG e a ordem dos notebooks vêm de `<Connections>`, não do layout do canvas | conferir ordem topológica do inventário contra a numeração dos notebooks |

```bash
# Contagem de nós no XML
grep -o '<Node ToolID=' PASTA_FLUXO/<fluxo>.yxmd | wc -l

# Anotações presentes
grep -rc "@alteryx tool_id=" PASTA_FLUXO/scripts PASTA_FLUXO/notebooks

# ToolIDs anotados no código (para cruzar com o inventário)
grep -rhoE "@alteryx tool_id=[0-9,]+" PASTA_FLUXO/scripts PASTA_FLUXO/notebooks \
  | sed 's/.*=//' | tr ',' '\n' | sort -un
```

⛔ ERRO em B.1, B.3 ou B.9 = **REPROVADO**. São as provas de que nada foi perdido nem inventado.

---

# Fase C — Estrutura e nomenclatura

| # | Check | Critério |
|---|---|---|
| C.1 | Intermediárias com **prefixo** `int_<prefixo>__<nome>` — dois underscores antes do nome | nunca sufixo `_int` |
| C.2 | Finais **sem** `int_`: `<prefixo>__<nome>` | — |
| C.3 | Nenhuma intermediária usando nome de tabela final, e vice-versa | cruzar com C.5 |
| C.4 | Notebooks seguem `<sequencia>_<nome_da_tabela_do_save>` | ex.: `001_int_planejamento__calculo` |
| C.5 | Variável `table` da primeira célula == nome do notebook sem o prefixo numérico | abrir cada notebook |
| C.6 | Numeração sequencial sem salto e sem duplicidade | `001, 002, 003...` |
| C.7 | Nome do notebook corresponde à tabela salva no `sv.save(df=df, tabela=table)` | — |
| C.8 | **Regra de quebra (4.01)** — notebook separado só onde há persistência reutilizada por notebook posterior | ver C.9 |
| C.9 | Sem quebra artificial: nenhum `001_filter` → `002_sort` → `003_join` | nome de notebook que descreve operação e não tabela = ERRO |
| C.10 | **Um save por notebook (4.11)** — um `sv.save()` por notebook | exceção: intermediárias simples que geram 1 tabela final no mesmo notebook e não são consumidas por outro notebook |
| C.11 | Estrutura do notebook segue `_fluxo_modelo` | seções: `table`, Imports/Parâmetros/Dados, Fluxo, Save |

```bash
# Saves por notebook (esperado: 1, salvo exceção 4.11)
grep -rc "sv\.save(" PASTA_FLUXO/notebooks/

# Sufixo _int indevido
grep -rn "_int\b" PASTA_FLUXO/notebooks/ | grep -v "int_"
```

---

# Fase D — Contratos: parâmetros e fontes

## D.1 Parâmetros

| # | Check | Critério |
|---|---|---|
| D.1.1 | Notebooks têm a célula de parâmetros com `names = [...]` e `args = utl.widgets_start(names=names)` | não usar `dbutils.widgets` direto |
| D.1.2 | Só os parâmetros necessários ao fluxo estão listados | parâmetro declarado e não usado = AVISO |
| D.1.3 | Nomes seguem `pr_<nome>` | `pr_ano`, `pr_mes`, `pr_versao` |
| D.1.4 | `_executor` declara os **mesmos** parâmetros dos notebooks | nome idêntico, sem tradução nem renome |
| D.1.5 | Dict `PARAMS` repassa com `args.get("pr_<nome>")` | — |
| D.1.6 | `_executor_master` chama o filho passando todos os parâmetros que ele exige | conferir no master |
| D.1.7 | Parâmetro em SQL sempre entre aspas: `ANO = '{args.get("pr_ano")}'` | sem aspas → `PARSE_SYNTAX_ERROR` |
| D.1.8 | `pr_mes` com zero-pad quando a comparação é `DATA_REF = 'YYYYMM'` | `'06'`, nunca `'6'` |

```bash
grep -rn "utl.widgets_start\|names\s*=\s*\[" PASTA_FLUXO/notebooks/
grep -rn "args.get(" PASTA_FLUXO/_executor
grep -rnE "=\s*\{args\.get\(" PASTA_FLUXO/notebooks/ | grep -v "'"   # parâmetro sem aspas
```

## D.2 Fontes de origem

Regra canônica: **[../_shared/fontes-origem.md](../_shared/fontes-origem.md)**. Checks de auditoria:

| # | Check |
|---|---|
| D.2.1 | Célula de Fontes contém `# ORIGEM ALTERYX:` com caminho completo para CADA fonte |
| D.2.2 | Cada fonte tem `# TIPO:` |
| D.2.3 | Cada fonte tem `# STATUS LAKE:` com valor válido — SIM / NÃO / VERIFICAR (`PARCIAL` descontinuado) |
| D.2.4 | Fonte de arquivo com caminho de rede/local completo, sem abreviação nem descrição genérica |
| D.2.5 | Fonte de banco com connection string e tabela/query original |
| D.2.6 | `fontes_origem` tem registro para este fluxo |
| D.2.7 | Sem duplicata de `fluxo` + `tool_id` |
| D.2.8 | Nenhum registro do fluxo com `existe_lake = 'PARCIAL'` |
| D.2.9 | `existe_lake = 'NÃO'` verificado contra `source_excel__<nome>__<guia>` e mapeamentos conhecidos |
| D.2.10 | `existe_lake = 'VERIFICAR'` com `obs_existe_lake` preenchida |
| D.2.11 | Toda fonte do notebook corresponde a um input real do `.yxmd` — conferir ToolIDs |
| D.2.12 | `levantamento_fontes_<fluxo>` no formato exato de `TEMPLATE_LEVANTAMENTO_FONTES` |

```sql
SELECT fluxo, tool_id, COUNT(*) c
FROM `dtlk-sandbox`.micracao_alteryx.fontes_origem
WHERE fluxo = '<fluxo>' GROUP BY 1,2 HAVING c > 1;

SELECT * FROM `dtlk-sandbox`.micracao_alteryx.fontes_origem
WHERE fluxo = '<fluxo>' AND (existe_lake = 'PARCIAL'
   OR (existe_lake = 'VERIFICAR' AND (obs_existe_lake IS NULL OR obs_existe_lake = '')));
```

⛔ D.2.6 vazio = **REPROVADO**. Migração sem fontes registradas é inválida.

---

# Fase E — Código e proibições

| # | Check | Critério |
|---|---|---|
| E.1 | **R2** — arquivos de `scripts/` são FILE, não notebook | sem `# Databricks notebook source` na linha 1, sem `# COMMAND ----------`, sem comando mágico, sem `dbutils` |
| E.2 | **R4** — notebook não chama script | sem `%run`, `import` ou `dbutils.notebook.run` de `notebooks/` para `scripts/` |
| E.3 | Sem DDL de temporária dentro de `spark.sql()` | grep abaixo — cobre `TEMP` e `TEMPORARY`, com e sem `OR REPLACE`, com e sem `GLOBAL` |
| E.4 | Transformação em Spark SQL; DataFrame API só quando justificada | bloco em DataFrame API sem justificativa = AVISO |
| E.5 | Lógica fiel ao `.yxmd` — sem regra, filtro, join ou coluna inventados | cruzar com o mapa de regras |
| E.6 | Toda coluna referenciada existe no schema real | `information_schema.columns` |
| E.7 | Substituição de fontes legadas por tabelas migradas aplicada onde cabia (lineage 4.10) | conferir contra AGENTS.md |
| E.8 | Tipo de carga documentado em célula comentada ao final | Append / Overwrite / Delete+Insert / Truncate+Insert / Merge-Upsert |
| E.9 | Evidência do Alteryx para o tipo de carga documentada | qual tool ou lógica indica |
| E.10 | **R10** — a carga é idempotente: reexecutar sobrescreve, não duplica | `Append` sem chave de deduplicação nem delete prévio = ERRO |
| E.11 | Dependências entre notebooks coerentes: se `002` lê `int_x`, existe `001` que a salva | montar o grafo |
| E.12 | Nenhuma persistência intermediária órfã — tabela salva e nunca relida | = AVISO, indica quebra desnecessária |

```bash
# E.1 — R2
head -1 PASTA_FLUXO/scripts/*.py | grep -n "Databricks notebook source"
grep -rn "# COMMAND ----------\|^%\|dbutils" PASTA_FLUXO/scripts/

# E.2 — R4
grep -rnE "%run.*scripts/|from +scripts|import +scripts|dbutils\.notebook\.run.*scripts" PASTA_FLUXO/notebooks/

# E.3 — DDL temporária, todas as variações
grep -rniE "CREATE[[:space:]]+(OR[[:space:]]+REPLACE[[:space:]]+)?(GLOBAL[[:space:]]+)?TEMP(ORARY)?[[:space:]]+(VIEW|TABLE)" \
  PASTA_FLUXO/notebooks PASTA_FLUXO/scripts
grep -rn "createGlobalTempView" PASTA_FLUXO/notebooks PASTA_FLUXO/scripts
# df.createOrReplaceTempView(...) é PERMITIDO e obrigatório — não sinalizar
```

---

# Ambiguidade no padrão

Se um check não puder ser decidido porque **o próprio padrão é ambíguo** — duas fontes do projeto dizendo coisas diferentes —, o resultado não é `[OK]` nem `[ERRO]`.

Registrar `[AMBIGUO]` com as duas referências conflitantes e escalar. Nunca resolver em silêncio escolhendo uma das leituras: a próxima execução escolheria a outra, e a divergência viraria comportamento não determinístico.

```
[AMBIGUO] C.1 | int_ prefixo x _int sufixo
          AGENTS.md regra 9 diz prefixo `int_`; processo.md Fase 5.4 dizia sufixo `_int`
          Ação: escalar para definição; não validar este item até resolver
```

Ambiguidade encontrada entra no relatório e vira proposta de correção do padrão — ver Encerramento no `SKILL.md`.
