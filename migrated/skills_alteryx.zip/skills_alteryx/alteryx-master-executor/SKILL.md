---
name: alteryx-master-executor
description: Ative para criar ou manter o notebook _executor_master que orquestra todos os fluxos de um domínio em ordem topológica. Gatilhos: 'cria o executor master', 'adiciona esse fluxo ao executor do domínio', 'atualiza a ordem de execução', 'o master não está chamando esse fluxo', 'qual a ordem certa dos executores'. Cuida de PARAMS compartilhados, dependências entre fluxos e comentários de ordem. O _executor de cada fluxo fica em PASTA_FLUXO/ (irmão de notebooks/), chamado como {BASE_PATH}/<Fluxo>/_executor.
---

# Skill: alteryx-master-executor

## Escopo

Criação e manutenção do notebook `_executor_master` que orquestra todos os fluxos de um domínio.

## Pre-requisitos

  readAssetById(assetType="file", assetId="/Workspace/Shared/Engineering/Migracao_Alteryx/AGENTS.md")

## Referência obrigatória

Modelo real: `/Workspace/Shared/Engineering/Migracao_Alteryx/Financeiro/_executor_master`

---

## Passo a Passo

### 1. Descobrir executores existentes

Localizar todos os notebooks `_executor` no domínio:
```
<dominio>/<Fluxo_A>/_executor
<dominio>/<Fluxo_B>/_executor
<dominio>/<Fluxo_C>/_executor
```

Para cada `_executor`, extrair:
- Parâmetros esperados (nomes exatos do `names = [...]`)
- Notebooks chamados e ordem
- Tabelas produzidas e consumidas

### 2. Analisar dependências entre fluxos

- Identificar tabelas produzidas por cada executor
- Identificar tabelas consumidas por cada executor
- Montar o grafo de dependências

Exemplo:
```
_executor de 01_CUSTOS      → produz: int_financeiro_custos__eventos_sistemicos
_executor de 02_CUSTEIO     → consome: int_financeiro_custos__eventos_sistemicos
                            → produz: financeiro_custos__volumetria_subcanal
```

### 3. Definir ordem de execução

- Sem dependências externas: executar primeiro
- Com dependências: executar após produtores
- **Comentar quais notebooks dependem de quais**, para que a ordem não seja alterada por engano

### 4. Criar/atualizar _executor_master

Estrutura obrigatória (conforme modelo real):

```python
# Célula 1 — Markdown título
%md
# EXECUTOR
##### Chamada sequencial de todos os notebooks da pasta <Dominio>

# Célula 2 — BASE_PATH + PARAMS
BASE_PATH = "/Shared/Engineering/Migracao_Alteryx/<Dominio>"
PARAMS = {
    "pr_ano": "<valor>",
    "pr_mes": "<valor>",
    "pr_versao": "<valor>",
}

# Célula 3 — Lista de notebooks (executores filhos)
notebooks = [
    # <Fluxo_A> — sem dependências externas
    f"{BASE_PATH}/<Fluxo_A>/_executor",

    # <Fluxo_B> — DEPENDE DE: Fluxo_A
    # Razão: consome int_<prefixo>__tabela produzida pelo Fluxo_A
    # NÃO alterar ordem sem verificar esta dependência.
    f"{BASE_PATH}/<Fluxo_B>/_executor",

    # <Fluxo_C> — DEPENDE DE: Fluxo_A e Fluxo_B
    f"{BASE_PATH}/<Fluxo_C>/_executor",
]

# Célula 4 — Chamada do setup_executor
%run /Shared/Engineering/Migracao_Alteryx/_libs/_setup_executor
```

---

## Regras de Parâmetros

- Repassar com os **MESMOS NOMES** declarados nos executores filhos
- Não criar traduções
- Não renomear
- Não omitir
- Se diferentes fluxos usam parâmetros diferentes, incluir **todos** no PARAMS

---

## Comentários Obrigatórios por Chamada

Para cada executor na lista:
```python
    # <Fluxo>: <breve descrição>
    # DEPENDE DE: <predecessores ou "Sem dependências">
    # Razão: <por que esta ordem é necessária>
    # NÃO alterar a ordem sem verificar estas dependências.
    f"{BASE_PATH}/<Fluxo>/_executor",
```

---

## Múltiplos Blocos de Execução

Se houver parâmetros diferentes para grupos de fluxos (ex: mês diferente), criar blocos separados de PARAMS + notebooks + `%run _setup_executor`, conforme feito no executor de Planejamento:

```python
# Bloco 1 — mês atual
PARAMS = {"pr_ano": "2026", "pr_mes": "06", ...}
notebooks = [...]
%run .../libs/_setup_executor

# Bloco 2 — mês anterior (para fluxos com defasagem)
PARAMS = {"pr_ano": "2026", "pr_mes": "04", ...}
notebooks = [...]
%run .../libs/_setup_executor
```

---

## Manutenção

Ao adicionar novo fluxo:
1. Ler o novo `_executor` (parâmetros e dependências)
2. Identificar posição correta na ordem
3. Inserir chamada na posição correta com comentários de dependência
4. Verificar se PARAMS cobre todos os parâmetros necessários

---

## Encerramento

Descoberta recorrente sobre ordenação de execução ou parâmetros compartilhados entre fluxos
segue **[../_shared/loop-feedback.md](../_shared/loop-feedback.md)**. Registrar como proposta;
promover ao AGENTS.md só o que valer para todos os domínios.
