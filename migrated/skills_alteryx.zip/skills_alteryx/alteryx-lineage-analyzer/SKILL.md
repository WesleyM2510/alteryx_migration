---
name: alteryx-lineage-analyzer
description: [PARCIALMENTE INATIVA — migração concluída] Mapear dependências entre fluxos Alteryx e tabelas. Modo 'antes da migração' (ordem de migração) inativo — não há mais migração a planejar. Modo 'após a migração' ainda vale sob demanda: validar lineage de fluxos em produção, atualizar fontes_origem ao descobrir mapeamento fonte→lake, consultar quem consome uma tabela. Gatilhos: 'quem depende dessa tabela?', 'esse fluxo lê de onde?', 'atualiza o lineage', 'essa fonte já existe no lake?'.
---

# Skill: alteryx-lineage-analyzer

> ## ⚠️ SKILL PARCIALMENTE INATIVA — migração concluída
>
> Esta skill tinha dois modos. Com todos os fluxos já migrados:
>
> - **"Antes da migração"** (mapear dependências e ordem de migração) — **inativo.** Não há mais
>   migração a planejar.
> - **"Após a migração"** (validar o lineage implementado, atualizar `fontes_origem` ao
>   descobrir mapeamento) — **ainda vale**, sob demanda, quando surgir dúvida sobre dependência
>   entre fluxos já em produção.
>
> Na prática, o que sobrevive é a atualização de `fontes_origem` e a consulta de dependências.
> A seção "Execução ANTES da Migração" fica como referência histórica.

## Escopo
Identificar e documentar dependencias entre fluxos Alteryx e fluxos migrados.

Executar:
  ANTES da migracao -> identificar dependencias e planejar ordem
  APOS  a migracao  -> validar o lineage implementado

## Pre-requisitos
  readAssetById(assetType="file", assetId="/Workspace/Shared/Engineering/Migracao_Alteryx/AGENTS.md")

---

## Execucao ANTES da Migracao

### 1. Inventario de fontes
Para cada .yxmd:
- Identificar todas as tabelas lidas (inputs)
- Identificar todas as tabelas gravadas (outputs)
- Registrar: nome, servidor/banco, tipo (SQL Server, Oracle, CSV...)

### 2. Mapeamento de dependencias entre fluxos
Para cada output de um fluxo:
- Verificar se algum outro fluxo le essa tabela como input
- Registrar: fluxo produtor -> tabela -> fluxo consumidor

### 3. Verificacao de equivalencias no Lake
Para cada tabela lida de fonte legada:
- Consultar AGENTS.md "Mapeamentos confirmados"
- Verificar se existe notebook migrado que gere essa tabela no Lake

### 4. Ordem de migracao sugerida
- Sem dependencias: migrar primeiro
- Com dependencias: migrar apos produtores
- Documentar a ordem

---

## Execucao APOS a Migracao

### 1. Verificar consistencia
- Todas as substituicoes de tabelas legadas foram realizadas?
- Dependencias pre-migracao foram respeitadas?

### 2. Atualizar inventario
- Registrar tabelas migradas
- Registrar tabelas ainda em fontes legadas
- Identificar lacunas sem equivalente no Lake

---

## Formato do Inventario de Lineage

  === INVENTARIO DE LINEAGE ===
  Fluxo: <nome>  |  Data: <data>

  INPUTS
  | Tabela | Origem | Equivalente no Lake | Status |
  | tabela_a | swap1478_pl.dbo | dtlk-sandbox.micracao_alteryx.xxx | Mapeado |
  | tabela_b | swap1478_pl.dbo | - | Sem equivalente |

  OUTPUTS
  | Tabela gerada | Notebook produtor | Fluxo |
  | dtlk-sandbox.micracao_alteryx.xxx | 001_xxx | Fluxo_A |

  DEPENDENCIAS ENTRE FLUXOS
  | Tabela | Fluxo Produtor | Fluxo Consumidor |
  | xxx__clientes | Fluxo_Cadastro | Fluxo_Faturamento |
  | xxx__clientes | Fluxo_Cadastro | Fluxo_Cobranca |

  ORDEM SUGERIDA DE MIGRACAO
  1. <fluxo_sem_dependencias>
  2. <fluxo_sem_dependencias>
  3. <fluxo_que_depende_de_1_e_2>

  TABELAS SEM EQUIVALENTE NO LAKE (requerem analise adicional)
  - tabela_b
  - tabela_c

---

## Referencia: Tabelas sem equivalente no Lake (do AGENTS.md)
rentabilidade_cartao, comissoes_ifrs, cadastro_contas, cadastro_produto_operacional,
cadastro_hie_produtos, funding_produto_taxa, funding_hist_taxas, bmg_card_tomb_parc,
t_parcelamentofatura, t_conta, dwd_cartao_conta_atual, cadastro_regras_canais_geral, cadastro_fontes

---

## [OBRIGATÓRIO] Atualização da tabela `fontes_origem`

Após cada análise de lineage, a tabela Delta `` `dtlk-sandbox`.micracao_alteryx.fontes_origem ``
DEVE ser atualizada.

Critério de `existe_lake`, schema, verificação de existência, verificação de duplicata,
INSERT, UPDATE e checklist: **[../_shared/fontes-origem.md](../_shared/fontes-origem.md)**.

Regra canônica única — não reescrever o conteúdo aqui.

O lineage é o momento em que mais mapeamento novo aparece. Sempre que descobrir que uma
fonte legada já tem equivalente no lake, aplicar o UPDATE (§6 do arquivo compartilhado)
para **todos** os registros daquela `tabela_sql` — não só o do fluxo em análise.

⛔ Análise de lineage sem atualização da tabela `fontes_origem` = análise incompleta.

---

## Encerramento

Descoberta de novo mapeamento fonte→lake, ou de dependência antes não registrada, segue a
regra canônica de captura: **[../_shared/loop-feedback.md](../_shared/loop-feedback.md)**.
Atualização de `fontes_origem` é o destino usual; só vira proposta ao AGENTS.md se for padrão
geral, não fato de um fluxo.
