---
name: fluxo-de-skills
description: Mapa único de qual skill roda quando e o que vem antes/depois de cada uma. Referência de orientação — consultar quando não estiver claro qual skill usar, ou em que ordem. Não executa nada; aponta. Editar aqui ao mudar o encadeamento.
---

# Fluxo de Skills — Migração Alteryx → Databricks

Mapa único do encadeamento. Cada skill aponta para cá em vez de descrever a cadeia inteira — assim, carregar uma skill isolada não esconde que existe um fluxo maior.

## Estado das skills

| Skill | Estado | Papel |
|---|---|---|
| `alteryx-flow-migrator` | ⛔ inativa | Referência do padrão de migração (parque já migrado) |
| `alteryx-lineage-analyzer` | ⚠️ parcial | Só o modo "após migração" (validar lineage, atualizar fontes) |
| `alteryx-flow-validator` | ✅ ativa | Valida conformidade estrutural |
| `alteryx-translation-validator` | ✅ ativa | Valida equivalência de dados |
| `alteryx-master-executor` | ✅ ativa | Cria/mantém o orquestrador do domínio |
| `alteryx-execution-monitor` | ✅ ativa | Vigia a execução mensal recorrente |

## A cadeia original de migração (histórica)

Era assim quando havia fluxos a migrar:

```
lineage-analyzer (antes)  →  flow-migrator  →  flow-validator  →  translation-validator  →  master-executor
   mapear ordem              converter          validar           validar dados            orquestrar
                                                 estrutura
```

Com a migração concluída, os dois primeiros passos não se repetem. O que resta ativo:

## O que roda hoje

**Validação de um fluxo** (quando um fluxo é corrigido ou revisitado):

```
flow-validator  →  translation-validator
   estrutura        dados
```

REPROVADO na estrutural **bloqueia** a de dados — reconciliar dado de fluxo com cobertura incompleta atribuiria à tradução uma divergência cuja causa é tool não migrada.

**Operação mensal** (todo período, em produção):

```
_executor_master (roda a carga)  →  execution-monitor (vigia o resultado)
```

O monitor dispara **depois** do executor, nunca em paralelo — ele lê o que a carga gravou.

**Sob demanda** (sem posição fixa na cadeia):

- `lineage-analyzer` — dúvida sobre dependência entre fluxos, ou atualização de `fontes_origem`
- `master-executor` — novo fluxo a inserir na ordem, ou ajuste de parâmetros do domínio

## Regras compartilhadas (não são skills de execução)

Consultadas por várias skills, nunca acionadas sozinhas:

| Arquivo | Quem consulta | Para quê |
|---|---|---|
| `_shared/fontes-origem.md` | migrator, lineage, flow-validator, translation-validator | Regra da tabela `fontes_origem` |
| `_shared/loop-feedback.md` | flow-validator, translation-validator, monitor, lineage, master-executor | Roteamento de descobertas |

## Onde cada descoberta deságua

O encerramento de toda skill ativa segue `_shared/loop-feedback.md`. Resumo do destino:

- Erro recorrente (tradução ou estrutura) → AGENTS.md, se geral
- Ambiguidade de padrão → escala para triagem
- Pendência de fluxo → `PENDENCIAS.md` daquele fluxo
- Fonte que mudou → `fontes_origem`
- Limiar mal calibrado → `monitor_config`
