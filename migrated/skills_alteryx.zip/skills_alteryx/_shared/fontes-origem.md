---
name: fontes-origem-regra-canonica
description: Regra canônica única da tabela fontes_origem: critério de existe_lake (SIM/NÃO/VERIFICAR — PARCIAL descontinuado), schema, verificação de existência e de duplicata, INSERT, UPDATE, checklist. Referenciada pelas skills de migração, lineage e validação — não é acionada isoladamente; é a fonte de verdade para onde os ponteiros ../_shared/ apontam. Editar aqui, e só aqui, ao mudar critério ou schema de fontes.
---

# Fontes de Origem — Regra Canônica

## When to Use

**Fonte única de verdade** para tudo que envolve a tabela `` `dtlk-sandbox`.micracao_alteryx.fontes_origem ``: critério de `existe_lake`, schema, procedimentos de verificação, INSERT, UPDATE e checklist.

Carregar sempre que a tarefa envolver fonte de origem — migração, lineage, validação estrutural ou de tradução.

> ⚠️ **Esta regra mora aqui e só aqui.** As skills apontam para este arquivo; nenhuma delas reescreve o conteúdo. Alterar critério ou schema = editar este arquivo. Se você encontrar a regra duplicada por extenso em outro lugar, é resíduo — substituir por ponteiro.

> ⚠️ O arquivo `fontes_origem.md` foi descontinuado. A tabela Delta é o ÚNICO controle.

**Dashboard:** "Fontes de Origem — Migração Alteryx"

---

## 1. Critério de `existe_lake` (DEFINIÇÃO OFICIAL)

A pergunta é uma só: **"Consigo acessar esta fonte via Databricks?"**

| Status | Significado |
|---|---|
| **SIM** | Acessível via Databricks — Delta nativo, Lakehouse Federation, Trino/Presto, catálogo externo, ou qualquer meio que permita `SELECT` funcional no Databricks |
| **NÃO** | Não acessível via Databricks — fonte exclusiva de rede local (Excel em UNC, ODBC sem Federation, banco sem catálogo externo) |
| **VERIFICAR** | Não foi possível determinar — DSN desconhecido, servidor não mapeado, requer análise manual |

**`PARCIAL` está descontinuado.** Lakehouse Federation e catálogo externo são **SIM** — o dado é acessível. O meio de acesso vai em `obs_existe_lake`, não no status.

Se encontrar `PARCIAL` em registro existente, corrigir para `SIM` ou `NÃO` conforme o critério acima e preencher `obs_existe_lake`.

### Valores aceitos

```
existe_lake ∈ { 'SIM', 'NÃO', 'VERIFICAR' }
```

Qualquer outro valor = ERRO. `PARCIAL` não é aceito em INSERT novo.

---

## 2. Schema da tabela

| Coluna | Tipo | Obrigatória | Descrição |
|---|---|---|---|
| `fluxo` | STRING | sim | Nome do .yxmd sem extensão |
| `dominio` | STRING | sim | Área: Auditoria, Financeiro/Custos, Tecnologia, etc. |
| `ano_auditoria` | STRING | não | Ano (só para Auditoria); NULL nos demais |
| `caminho_yxmd` | STRING | não | Path relativo do .yxmd no projeto |
| `tool_id` | STRING | sim | ToolID do input no Alteryx |
| `plugin` | STRING | não | Plugin Alteryx |
| `tipo_origem` | STRING | sim | Excel, CSV, SQL Server/ODBC, TXT, Alteryx DB, Access |
| `caminho_completo` | STRING | sim | Caminho UNC/local, ou connection string + query |
| `servidor` | STRING | não | Servidor de rede ou DSN |
| `dsn` | STRING | não | DSN ODBC |
| `database_name` | STRING | não | Database name |
| `tabela_sql` | STRING | não | Tabela principal referenciada |
| `sheet_name` | STRING | não | Aba do Excel |
| `connection_string` | STRING | não | Connection string completa |
| `existe_lake` | STRING | sim | SIM / NÃO / VERIFICAR — ver §1 |
| `obs_existe_lake` | STRING | condicional | **OBRIGATÓRIA quando `existe_lake = 'VERIFICAR'`**; recomendada quando SIM via Federation/Trino, para registrar o meio de acesso |
| `tabela_lake` | STRING | não | Tabela equivalente no lake |
| `data_extracao` | TIMESTAMP | sim | `current_timestamp()` |

---

## 3. Verificação de existência no lake (antes de definir `existe_lake`)

**Nunca marcar `NÃO` sem executar a verificação.** Em caso de dúvida, `VERIFICAR` com `obs_existe_lake` preenchida.

### Arquivo (Excel / TXT / CSV)

Padrão de nomenclatura no lake:

- Excel: `source_excel__<nome_snake_case>__<guia_snake_case>`
- TXT/CSV: `source_txt__<nome_descritivo>`

Exemplo: `Evento 061.xlsx`, guia `Base` → `source_excel__evento_061__base`

```python
def check_source_exists(nome_tabela_esperada):
    try:
        spark.sql(f"DESCRIBE `dtlk-sandbox`.micracao_alteryx.{nome_tabela_esperada}")
        return "SIM", f"dtlk-sandbox.micracao_alteryx.{nome_tabela_esperada}"
    except Exception:
        return "NÃO", None
```

Alternativa por padrão de nome:

```sql
SHOW TABLES IN `dtlk-sandbox`.micracao_alteryx LIKE 'source_excel__<nome>*';
SHOW TABLES IN `dtlk-sandbox`.micracao_alteryx LIKE 'source_txt__<nome>*';
```

### SQL Server / ODBC

Consultar os mapeamentos confirmados no AGENTS.md **e** os registros já existentes na tabela:

```sql
SELECT DISTINCT tabela_sql, existe_lake, tabela_lake
FROM `dtlk-sandbox`.micracao_alteryx.fontes_origem
WHERE tabela_sql = '<TABELA>' AND existe_lake = 'SIM';
```

---

## 4. Verificação de duplicata (antes de todo INSERT)

Chave lógica: **`fluxo` + `tool_id`**.

```sql
SELECT COUNT(*) FROM `dtlk-sandbox`.micracao_alteryx.fontes_origem
WHERE fluxo = '<nome_fluxo>' AND tool_id = '<tool_id>';
-- > 0 → NÃO inserir (já existe); avaliar UPDATE
```

```python
existing = spark.sql("""
    SELECT 1 FROM `dtlk-sandbox`.micracao_alteryx.fontes_origem
    WHERE fluxo = '<nome_fluxo>' AND tool_id = '<tool_id>'
""").count()

if existing == 0:
    spark.sql("""INSERT INTO ...""")
```

Auditoria de duplicatas já existentes:

```sql
SELECT fluxo, tool_id, COUNT(*) AS c
FROM `dtlk-sandbox`.micracao_alteryx.fontes_origem
WHERE fluxo = '<fluxo>'
GROUP BY fluxo, tool_id
HAVING COUNT(*) > 1;
-- resultado não vazio = ERRO; corrigir com DELETE do duplicado
```

---

## 5. INSERT

```python
spark.sql("""
INSERT INTO `dtlk-sandbox`.micracao_alteryx.fontes_origem
(fluxo, dominio, ano_auditoria, caminho_yxmd, tool_id, plugin, tipo_origem,
 caminho_completo, servidor, dsn, database_name, tabela_sql, sheet_name,
 connection_string, existe_lake, obs_existe_lake, tabela_lake, data_extracao)
VALUES
  ('<nome_fluxo>', '<dominio>', NULL, '<caminho.yxmd>', '<tool_id>',
   'AlteryxBasePluginsGui.DbFileInput.DbFileInput', '<tipo>',
   '<caminho_completo>', '<servidor>', '<dsn>', '<database>',
   '<tabela>', '<sheet>', '<conn_string>',
   '<SIM|NÃO|VERIFICAR>', '<obs_ou_null>', '<tabela_lake_ou_null>',
   current_timestamp())
""")
```

Exemplos de `obs_existe_lake`:

- SIM via Federation: "Acessível via Lakehouse Federation (`swap1478_pl.dbo.X`); não migrada nativamente — depende do SQL Server online."
- VERIFICAR: "DSN não reconhecido — conferir se existe tabela equivalente no lake."
- VERIFICAR: "Query complexa com JOIN — conferir se o resultado já existe como tabela migrada."

---

## 6. UPDATE — atualização contínua

A tabela é atualizada **em qualquer interação** que envolva mapeamento de fonte, não só durante migração formal:

- Confirmou que a fonte existe no lake → `existe_lake` + `tabela_lake`
- Carregou um novo Excel/TXT no lake → registro correspondente
- Descobriu novo mapeamento SQL Server → Lake → todos os registros daquela `tabela_sql`
- Corrigiu informação (servidor, DSN, `sheet_name`) → o registro

```sql
-- Por tabela SQL identificada
UPDATE `dtlk-sandbox`.micracao_alteryx.fontes_origem
SET existe_lake = 'SIM',
    tabela_lake = '<tabela>',
    data_extracao = current_timestamp()
WHERE tabela_sql = '<TABELA>' AND existe_lake IN ('NÃO', 'VERIFICAR');
```

```python
# Por padrão de caminho
spark.sql(f"""
UPDATE `dtlk-sandbox`.micracao_alteryx.fontes_origem
SET existe_lake = 'SIM',
    tabela_lake = '{tabela_lake}',
    data_extracao = current_timestamp()
WHERE LOWER(caminho_completo) LIKE '%{pattern}%'
  AND existe_lake <> 'SIM'
""")
```

**Regra de ouro:** mencionou fonte + lake na mesma conversa → atualizar a tabela.

---

## 7. Checklist

- [ ] Toda fonte anotada com `# ORIGEM ALTERYX:` na Célula 5 do notebook
- [ ] Caminho exato do `.yxmd`, sem abreviação ou descrição genérica
- [ ] Verificação de existência no lake executada para cada fonte (§3)
- [ ] Verificação de duplicata executada antes do INSERT (§4)
- [ ] INSERT executado, sem duplicata de `fluxo` + `tool_id`
- [ ] `existe_lake` ∈ { SIM, NÃO, VERIFICAR } — nenhum `PARCIAL`
- [ ] `obs_existe_lake` preenchida quando `VERIFICAR`
- [ ] Dashboard reflete os dados inseridos

## 8. Erros bloqueantes

| Condição | Consequência |
|---|---|
| Migração sem INSERT na tabela | Migração inválida |
| INSERT sem verificação de duplicata | Violação de processo |
| `existe_lake = 'NÃO'` sem verificação prévia | Violação de processo |
| `existe_lake = 'VERIFICAR'` sem `obs_existe_lake` | ERRO — deve conter explicação |
| `existe_lake = 'PARCIAL'` em registro novo | ERRO — valor descontinuado (§1) |
| Fonte sem caminho de origem documentado | ERRO bloqueante na validação |
