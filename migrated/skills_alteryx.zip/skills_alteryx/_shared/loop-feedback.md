---
name: loop-feedback-regra-canonica
description: Regra canônica única do loop de feedback: para onde vai cada descoberta (tabela de roteamento), critério de promoção (reproduzível + verificável + geral, segunda ocorrência), triagem por dono humano, orçamento e poda do AGENTS.md. Referenciada no encerramento das skills que emitem veredito ou diagnóstico — não é acionada isoladamente. Editar aqui, e só aqui, ao mudar o roteamento de descobertas.
---

# Loop de Feedback — Captura de Descobertas

## When to Use

**Fonte única de verdade** para o que toda skill faz ao descobrir algo novo: para onde vai, quem decide se entra, e sob que critério. Carregar no encerramento de qualquer skill que produza veredito ou diagnóstico.

> ⚠️ Esta regra mora aqui e só aqui. As skills apontam para este arquivo no seu passo de encerramento; nenhuma reescreve o roteamento. Mesma disciplina do `_shared/fontes-origem.md`.

## Por que centralizar

Sem regra única, cada skill inventa seu próprio destino para descobertas, e o AGENTS.md — que é carregado em toda execução — cresce sem controle. Um AGENTS.md inchado degrada todas as rodadas, porque todo agente lê tudo antes de agir. O loop de feedback só é saudável se tiver **porta de entrada estreita e dono de triagem**; caso contrário, vira depósito.

---

## 1. Tabela de roteamento

Cada tipo de descoberta tem **um** destino. Não improvisar.

| Descoberta | Destino | Tag |
|---|---|---|
| Erro de tradução recorrente (padrão que se repete entre fluxos) | AGENTS.md → "Erros Recorrentes" | `[traducao]` |
| Violação estrutural recorrente | AGENTS.md → "Erros Recorrentes" | `[estrutura]` |
| Armadilha semântica Alteryx→Spark nova | `semantica-alteryx-spark.md` **e** `checklist-semantico.md` | — |
| Ambiguidade do próprio padrão (duas fontes se contradizem) | AGENTS.md → correção da regra ambígua | `[ambiguo]` |
| Pendência sem resolução (ToolID não mapeável, pergunta em aberto) | `PENDENCIAS.md` do fluxo | — |
| Limiar de monitoramento mal calibrado | `monitor_config` (ajuste de valor) | — |
| Mudança de disponibilidade de fonte | `fontes_origem` (UPDATE) | — |
| Sintoma de divergência novo (assinatura → tool → causa) | `diagnostico-divergencias.md` | — |

Regra de ouro do roteamento: **AGENTS.md recebe só o que se aplica a todos os fluxos.** Achado específico de um fluxo vai para o artefato daquele fluxo (`PENDENCIAS.md`), nunca para o contexto global.

---

## 2. Critério de promoção

Nem toda descoberta vira regra. O filtro tem três condições — **as três** precisam valer:

1. **Reproduzível** — aconteceu de forma que se repetiria em outro fluxo nas mesmas condições, não um acidente isolado de um `.yxmd` malformado.
2. **Verificável** — dá para escrever um check que a detecta (grep, query, contagem). Regra que ninguém consegue verificar automaticamente não se sustenta; vira folclore.
3. **Geral** — vale para o projeto, não para um caso único. Um único fluxo esquisito não deve gerar regra que passa a constranger todos os outros.

Falhou uma? Não promove. Vai para `PENDENCIAS.md` como observação, e espera a segunda ocorrência. **Primeira ocorrência não vira regra** — a barra é a segunda aparição confirmada, que é o que distingue padrão de acaso.

---

## 3. Triagem

Descoberta que passa no critério não entra sozinha no AGENTS.md — é **proposta**, não commit direto.

- A skill **registra a proposta** no seu relatório, com a tag de roteamento e a evidência (arquivo:linha, contagem, as duas referências no caso de ambiguidade).
- Um **humano dono da triagem** revisa e decide a inclusão. Sem dono, a porta fica aberta e o AGENTS.md incha — o oposto do que a consolidação do `_shared` buscou.
- O papel de triagem é do time, não de uma skill. Definir **quem** é decisão de processo do projeto; enquanto não houver dono nomeado, as propostas ficam acumuladas no relatório e nada entra no AGENTS.md automaticamente.

> **Ponto em aberto para o projeto decidir:** quem é o dono da triagem, e com que cadência revisa as propostas. Até isso existir, o loop registra mas não promove — o que é seguro (nada entra sem revisão), ao custo de as propostas ficarem represadas.

---

## 4. Orçamento e poda do AGENTS.md

O AGENTS.md é carregado em toda execução, então seu tamanho é custo recorrente de todas as rodadas.

- **Teto:** ao promover uma regra, verificar se ela **substitui** uma anterior mais fraca em vez de só somar. Erro recorrente que passou a ter check no validador pode sair da lista textual — o check virou a regra.
- **Poda periódica:** regra cuja violação já é pega por check automático não precisa continuar como texto no AGENTS.md. O check é a regra; o texto é redundância.
- **Mesma disciplina do P0, no tempo:** o P0 removeu duplicação no espaço (uma regra, um lugar); a poda remove duplicação no tempo (regra que virou check não precisa do texto).

---

## 5. Formato da proposta no relatório

Toda skill encerra propostas de feedback neste formato:

```text
=== PROPOSTAS DE FEEDBACK ===
[traducao]  Recorrência: fan-out de join por chave não única em 3 fluxos
            Evidência: producao_det (t42), interchange (t18), saques (t31)
            Check proposto: Q-FANOUT no diagnóstico já detecta; promover a regra
            Critério: reproduzível ✓ verificável ✓ geral ✓ → PROMOVER
            Destino: AGENTS.md "Erros Recorrentes"

[ambiguo]   Padrão se contradiz: nomenclatura de intermediária
            Refs: AGENTS.md regra 9 (prefixo int_) x processo.md 5.4 (sufixo _int)
            Critério: não é erro de fluxo, é do padrão → ESCALAR
            Destino: correção da regra ambígua; aguarda dono de triagem
```

Proposta sem os três critérios avaliados, ou sem destino da tabela §1, é proposta incompleta — não encaminhar.
