---
name: alteryx-execution-monitor
description: Ative para monitorar a EXECUÇÃO MENSAL RECORRENTE dos fluxos já migrados — se a carga de cada período veio íntegra. Diferente das skills de validação (que atuam uma vez, na migração), esta vigia a produção mês a mês. Gatilhos: 'a carga desse mês está certa?', 'monitora a execução', 'o volume caiu esse mês?', 'faltou dado na carga', 'compara com os meses anteriores', após rodar o _executor_master. Compara período atual contra histórico da própria tabela (month-over-month, média móvel, valor de negócio, frescor). Detecta carga parcial, reexecução com append, fonte que sumiu, join quebrado. Notifica, não bloqueia.
---

# Skill: alteryx-execution-monitor

## Escopo

Monitorar a **execução recorrente** dos fluxos já migrados. Depois que a migração termina, o `_executor_master` roda todo mês em produção — e nenhuma outra skill olha para essa execução. Esta skill vigia o resultado mensal: volumetria, valor de negócio e frescor, comparando cada período contra o histórico da própria tabela.

Não confundir com as skills de validação, que atuam uma vez, no momento da migração:

| Skill | Quando | Compara |
|---|---|---|
| `alteryx-flow-validator` | uma vez, na migração | código × padrão do projeto |
| `alteryx-translation-validator` | uma vez, na migração | resultado migrado × Alteryx original |
| **`alteryx-execution-monitor`** | **todo mês, em produção** | **período atual × histórico da mesma tabela** |

A diferença de fundo: a validação pergunta "a tradução está certa?". O monitor pergunta "a execução deste mês veio íntegra?" — uma tradução perfeita ainda produz dado quebrado se uma fonte parar de chegar, se um lote vier parcial, ou se a carga rodar duas vezes.

## Por que existe

O `_executor_master` tem bloco de mês atual e bloco de mês anterior, parametrizado por `pr_ano`/`pr_mes`. Isso executa indefinidamente. Os riscos que sobram **depois** que a tradução foi validada:

- **Carga parcial** — uma fonte veio incompleta; a tabela final tem metade das linhas
- **Reexecução com append** — a carga rodou duas vezes; volume dobrado (viola R10)
- **Fonte que parou** — um subcanal ou família de produto sumiu da origem
- **Join quebrado a montante** — registro chega, valor vem nulo ou zero
- **Buraco de período** — uma reexecução malfeita apagou um mês anterior

Nenhum desses é erro de tradução. Todos passam pelas duas skills de validação — que já aprovaram o fluxo — e só aparecem em produção.

## Pre-requisitos

  readAssetById(assetType="file", assetId="/Workspace/Shared/Engineering/Migracao_Alteryx/AGENTS.md")

Ler também:
- O cadastro de tabelas monitoradas (§Cadastro) — quais tabelas, qual coluna de valor, quais limiares
- Regra canônica de fontes, se o alerta apontar para fonte: [../_shared/fontes-origem.md](../_shared/fontes-origem.md)

## Ao receber o pedido

Perguntar:

1. **Qual período acabou de ser carregado?** (`pr_ano`/`pr_mes` da execução mensal)
2. **Monitorar todas as tabelas finais do domínio, ou uma lista específica?**
3. **É a primeira vez?** Se sim, não há histórico calibrado — a primeira execução estabelece a linha de base, e os limiares são provisórios até haver alguns períodos acumulados.

---

## Fase M — Monitoramento

Aplicar [queries-monitoramento.md](queries-monitoramento.md) a cada tabela final. Cinco checks, do mais barato ao mais fino:

| Check | O que pega | Custo |
|---|---|---|
| M1 — volumetria vs anterior | carga parcial, volume dobrado, período vazio | baixo |
| M2 — volumetria vs média móvel | quebra sustentada que o M1 não vê | baixo |
| M3 — desvio por dimensão | *onde* o volume mudou; fonte que sumiu | médio |
| M4 — soma de valor de negócio | join quebrado (linha ok, valor nulo/zero) | médio |
| M5 — frescor e cobertura | período atual ausente, buraco na sequência | baixo |

**Ordem de leitura:** rodar M1, M2 e M5 sempre (são baratos e cobrem as falhas mais comuns). M3 e M4 só quando M1 ou M2 dispararem — eles localizam a causa do desvio que os baratos detectaram.

Só uma representação de período existe por tabela; para tabelas com colunas `ANO`/`MES` separadas, aplicar a normalização da §0 do arquivo de queries antes de qualquer check.

---

## Cadastro de tabelas monitoradas

O monitor precisa saber, por tabela: qual coluna de valor acompanhar, qual dimensão quebrar, e qual limiar dispara alerta. Guardar isso em tabela Delta, no mesmo padrão do controle de fontes — não em arquivo, para o dashboard poder consumir.

**Tabela sugerida:** `` `dtlk-sandbox`.micracao_alteryx.monitor_config ``

| Coluna | Descrição |
|---|---|
| `tabela` | Nome da tabela final monitorada |
| `dominio` | Área de negócio |
| `col_periodo` | `DATA_REF`, ou `ANO/MES` para as que precisam de derivação |
| `col_valor` | Coluna numérica de negócio (ex.: `PDU_VLR_LIB`) |
| `dimensao` | Quebra para o M3 (ex.: `FAMILIA_PRODUTO`) |
| `limiar_mom_pct` | Limite de variação mês-a-mês antes de alertar (padrão 35) |
| `limiar_zscore` | Limite de z-score na média móvel (padrão 2) |
| `k_media_movel` | Janela da média móvel (padrão 6) |
| `ativo` | Se a tabela entra na rodada mensal |

A calibração dos limiares é por tabela: uma tabela de fechamento contábil é estável e tolera limiar apertado; uma de produção transacional oscila mais e pede folga. O primeiro valor é chute informado; ajustar conforme os falsos positivos aparecerem.

---

## Automação

Agendar como Lakeflow Job, **disparado após o `_executor_master`** — o monitor lê o que a execução mensal gravou, então roda depois dela, nunca em paralelo.

- Executar com service principal, não token pessoal
- Um job por domínio, ou um job único iterando o `monitor_config`
- Persistir o resultado de cada rodada (ver §Histórico) para o dashboard

Se qualquer tabela dispara alerta, o job **não deve falhar** — diferente do gate de cutover da reconciliação, aqui o objetivo é notificar, não bloquear. A execução mensal já aconteceu; o dado já está gravado. Falhar o job não desfaz nada, só esconde o alerta atrás de um stack trace. Notificar (e-mail, Slack, ou linha no dashboard) é a resposta certa.

---

## Histórico e dashboard

Persistir cada rodada em `` `dtlk-sandbox`.micracao_alteryx.monitor_historico `` — uma linha por tabela, por período, por check, com o valor observado e o status. Isso serve a três coisas:

- **Tendência** — o dashboard mostra a série, não só o ponto atual
- **Calibração** — os limiares se ajustam olhando os falsos positivos acumulados
- **Auditoria** — prova de que a execução foi vigiada, mês a mês

Dashboard sugerido: "Monitor de Execução — Migração Alteryx", separado do dashboard de fontes.

---

## Formato do Relatório

```text
=== MONITOR DE EXECUÇÃO ===
Período carregado: pr_ano=2026 pr_mes=08  |  Data da rodada: <data>
Tabelas monitoradas: <n>  |  Alertas: <m>

[OK]     planejamento__interchange            | M1 +2.3% | M2 z=0.4 | M5 202608 presente
[ALERTA] planejamento__producao_det_cartoes   | M1 -47% vs 202607
         M3: FAMILIA_PRODUTO 'CARTAO_CONSIGNADO' sumiu (era 12.400 linhas)
         Hipótese: fonte producao_det não trouxe o subcanal — verificar origem
[ALERTA] planejamento__base_motor_saques      | M4 soma estável, nulos +8.200
         Hipótese: join com cadastro_subcanais perdeu match — valor não chegou

Resumo: <n> tabelas | <ok> ok | <m> alertas
Ações sugeridas (ordem de investigação):
1. producao_det_cartoes — conferir se o subcanal existe na fonte do período
2. base_motor_saques — checar cadastro_subcanais no período
```

---

## Encerramento

Captura de descobertas conforme **[../_shared/loop-feedback.md](../_shared/loop-feedback.md)**:

1. **Alerta confirmado como problema de fonte** → registrar na `fontes_origem` se mudou o status de disponibilidade da fonte; a causa costuma ser origem que parou de chegar.
2. **Padrão de alerta recorrente** (mesma tabela, mesmo check, meses seguidos) → pode não ser incidente, e sim limiar mal calibrado. Reavaliar o `monitor_config` antes de tratar como falha (roteamento: ajuste de limiar, não regra no AGENTS.md).
3. **Falso positivo** → ajustar o limiar da tabela e registrar o novo valor no cadastro, com a justificativa.

O monitor não corrige nada — ele detecta e localiza. A correção de carga segue o processo de operação do domínio; a correção de tradução (se o alerta revelar um erro que passou pela validação) reentra na `alteryx-translation-validator`.

---

## Reference Files

- [queries-monitoramento.md](queries-monitoramento.md) — templates de comparação temporal (M1–M5) e snippet de execução consolidada

## Caminhos e Convenções

| Referência | Valor |
|---|---|
| Cadastro de monitoramento | `` `dtlk-sandbox`.micracao_alteryx.monitor_config `` |
| Histórico de rodadas | `` `dtlk-sandbox`.micracao_alteryx.monitor_historico `` |
| Dashboard | Monitor de Execução — Migração Alteryx |
| Dispara após | `_executor_master` do domínio |
