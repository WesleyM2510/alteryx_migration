# Queries de Monitoramento de Execução

## When to Use

Fase M da `alteryx-execution-monitor`. Templates de comparação temporal — o período recém-carregado contra o histórico da **mesma tabela**. Não há REF externa: a referência é o próprio passado da tabela.

Placeholders:

| Placeholder | Significado |
|---|---|
| `{TABELA}` | `` `dtlk-sandbox`.micracao_alteryx.<prefixo>__<tabela> `` |
| `{PERIODO}` | Coluna de período — `DATA_REF` (string `'YYYYMM'`) na maioria; ver §0 para o caso ANO/MES |
| `{ATUAL}` | Período recém-carregado (ex.: `'202608'`) |
| `{ANTERIOR}` | Período imediatamente anterior (ex.: `'202607'`) |
| `{K}` | Janela da média móvel (padrão 6) |
| `{COL_VALOR}` | Coluna numérica de negócio a monitorar (ex.: `PDU_VLR_LIB`) |
| `{DIMENSAO}` | Quebra relevante (ex.: `FAMILIA_PRODUTO`, `COD_SUBCANAL`) |

Regra geral: tudo roda no Spark, sobre a tabela final já persistida. O monitor **não reprocessa** — ele lê o que a execução mensal gravou.

---

## 0. Normalização do período

Duas representações no projeto (AGENTS.md, "Padrões de Filtro Temporal"):

- **Transacionais:** `DATA_REF` string `'YYYYMM'` — usar direto.
- **Colunas ANO/MES separadas** (ex.: `interchange`, `comissoes_ifrs`): derivar antes de comparar.

Para tabelas ANO/MES, criar a coluna derivada na CTE de entrada:

```sql
WITH base AS (
  SELECT *, CONCAT(ano, LPAD(mes, 2, '0')) AS DATA_REF
  FROM {TABELA}
)
-- daqui em diante, tratar como DATA_REF
```

Todos os templates abaixo assumem `DATA_REF` string `'YYYYMM'`. Para ANO/MES, aplicar a CTE acima e apontar `{TABELA}` para `base`.

---

## 1. M1 — Volumetria contra o período anterior

O check mais barato e o que pega a falha mais comum: carga parcial ou dobrada.

```sql
-- Q-MOM: mês contra mês (month-over-month)
SELECT
  '{ANTERIOR}' AS periodo_ant, ant.linhas AS linhas_ant,
  '{ATUAL}'    AS periodo_atu, atu.linhas AS linhas_atu,
  atu.linhas - ant.linhas                      AS delta_abs,
  ROUND(100.0 * (atu.linhas - ant.linhas) / NULLIF(ant.linhas, 0), 2) AS delta_pct
FROM (SELECT COUNT(*) AS linhas FROM {TABELA} WHERE {PERIODO} = '{ANTERIOR}') ant
CROSS JOIN
     (SELECT COUNT(*) AS linhas FROM {TABELA} WHERE {PERIODO} = '{ATUAL}')    atu;
```

Interpretação:

| `delta_pct` | Leitura |
|---|---|
| ≈ 0 a ±5% | Variação normal de volume transacional |
| −40% a −60% | **Suspeita de carga parcial.** Um lote faltando, um filtro cortando demais |
| ≈ −100% | Período atual vazio — carga não rodou ou gravou em partição errada |
| ≈ +100% | Volume dobrado — **reexecução com append** (viola R10 de idempotência) |

## 2. M2 — Volumetria contra a média móvel

Month-over-month sozinho tem um ponto cego: se dois meses seguidos vierem quebrados na mesma proporção, o delta entre eles é zero e nada dispara. A média móvel de `{K}` períodos é a defesa.

```sql
-- Q-MOVAVG: atual contra a média dos {K} períodos anteriores
WITH por_periodo AS (
  SELECT {PERIODO} AS periodo, COUNT(*) AS linhas
  FROM {TABELA}
  WHERE {PERIODO} < '{ATUAL}'
  GROUP BY {PERIODO}
  ORDER BY {PERIODO} DESC
  LIMIT {K}
),
media AS (
  SELECT AVG(linhas) AS media_movel, STDDEV(linhas) AS desvio FROM por_periodo
)
SELECT
  atu.linhas                          AS linhas_atual,
  ROUND(m.media_movel, 0)             AS media_movel_k,
  ROUND(m.desvio, 0)                  AS desvio_padrao,
  ROUND((atu.linhas - m.media_movel) / NULLIF(m.desvio, 0), 2) AS z_score
FROM (SELECT COUNT(*) AS linhas FROM {TABELA} WHERE {PERIODO} = '{ATUAL}') atu
CROSS JOIN media m;
```

`z_score` fora de ±2 = o período atual desvia mais de dois desvios-padrão da tendência recente. É o gatilho estatístico, mais robusto que um limiar percentual fixo.

## 3. M3 — Onde o desvio mora (por dimensão)

Volumetria total diz *que* há problema; a quebra por dimensão diz *onde*. Reaproveita a lógica da `Q-VOL-GRUPO` da reconciliação, com eixo temporal.

```sql
-- Q-MOM-DIM: delta por dimensão, atual vs anterior
WITH ant AS (
  SELECT {DIMENSAO} AS dim, COUNT(*) AS linhas
  FROM {TABELA} WHERE {PERIODO} = '{ANTERIOR}' GROUP BY {DIMENSAO}
),
atu AS (
  SELECT {DIMENSAO} AS dim, COUNT(*) AS linhas
  FROM {TABELA} WHERE {PERIODO} = '{ATUAL}' GROUP BY {DIMENSAO}
)
SELECT
  COALESCE(atu.dim, ant.dim) AS dimensao,
  ant.linhas AS ant, atu.linhas AS atu,
  COALESCE(atu.linhas, 0) - COALESCE(ant.linhas, 0) AS delta,
  CASE WHEN ant.dim IS NULL THEN 'DIMENSÃO NOVA'
       WHEN atu.dim IS NULL THEN 'DIMENSÃO SUMIU'
       ELSE 'AMBOS' END AS status
FROM ant FULL OUTER JOIN atu ON ant.dim <=> atu.dim
ORDER BY ABS(COALESCE(atu.linhas, 0) - COALESCE(ant.linhas, 0)) DESC;
```

"DIMENSÃO SUMIU" é o sinal mais acionável: uma família de produto ou um subcanal que existia e desapareceu aponta direto para a fonte que parou de chegar.

## 4. M4 — Soma de valor de negócio

Contagem de linhas pode bater e o valor não — registro presente com valor zerado ou nulo por falha de join a montante. Monitorar a soma da coluna que o negócio reconhece.

```sql
-- Q-SUM-MOM: soma de valor, atual vs anterior + média móvel
WITH serie AS (
  SELECT {PERIODO} AS periodo,
         SUM({COL_VALOR})                       AS total,
         COUNT(*)                               AS linhas,
         SUM(CASE WHEN {COL_VALOR} IS NULL THEN 1 ELSE 0 END) AS nulos,
         SUM(CASE WHEN {COL_VALOR} = 0 THEN 1 ELSE 0 END)     AS zeros
  FROM {TABELA}
  WHERE {PERIODO} <= '{ATUAL}'
  GROUP BY {PERIODO}
)
SELECT * FROM serie ORDER BY periodo DESC LIMIT {K};
```

Ler a série inteira, não só o último ponto. Um salto em `nulos` ou `zeros` no período atual, mesmo com `linhas` estável, é a assinatura de join quebrado — o registro chegou, o valor não.

## 5. M5 — Frescor e cobertura de período

O período que deveria existir, existe?

```sql
-- Q-PERIODOS: últimos períodos presentes na tabela
SELECT {PERIODO} AS periodo, COUNT(*) AS linhas
FROM {TABELA}
GROUP BY {PERIODO}
ORDER BY {PERIODO} DESC
LIMIT 13;
```

Confere duas coisas de uma vez: o período atual aparece (carga rodou), e não há buraco na sequência (nenhum mês anterior sumiu de uma reexecução malfeita). Treze linhas dão o ano corrente mais um mês de folga para comparação.

---

## Snippet de execução consolidada

Rodar as cinco em sequência sobre uma tabela e coletar os resultados num só lugar:

```python
# --- monitor de uma tabela final ---
TABELA   = "`dtlk-sandbox`.micracao_alteryx.planejamento__producao_det_cartoes"
PERIODO  = "DATA_REF"
ATUAL    = "202608"
ANTERIOR = "202607"
K        = 6
COL_VALOR = "PDU_VLR_LIB"
DIMENSAO  = "FAMILIA_PRODUTO"

alertas = []

def check(nome, df, regra):
    row = df.first()
    ok = regra(row)
    status = "OK" if ok else "ALERTA"
    if not ok:
        alertas.append((TABELA, nome, row.asDict()))
    print(f"[{status}] {nome} | {row.asDict()}")

# M1 — variação vs anterior dentro de ±35%
check("M1_volumetria_mom",
      spark.sql(q_mom),
      lambda r: r.delta_pct is not None and abs(r.delta_pct) <= 35)

# M2 — z-score dentro de ±2
check("M2_media_movel",
      spark.sql(q_movavg),
      lambda r: r.z_score is not None and abs(r.z_score) <= 2)

# M5 — período atual presente
check("M5_frescor",
      spark.sql(f"SELECT MAX({PERIODO}) AS ult FROM {TABELA}"),
      lambda r: r.ult == ATUAL)

if alertas:
    print(f"\n{len(alertas)} alerta(s) — ver detalhe por dimensão (M3) e valor (M4)")
```

Os limiares (`±35%`, `±2`) são ponto de partida — cada tabela calibra o seu conforme a volatilidade natural do negócio, e o valor escolhido fica registrado no cadastro de tabelas monitoradas (ver SKILL.md §Cadastro).
