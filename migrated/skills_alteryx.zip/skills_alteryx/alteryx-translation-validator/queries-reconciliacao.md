# Queries de Reconciliação e Instrumentação

## When to Use

Fases C e D. Templates parametrizados — substituir os placeholders antes de executar:

| Placeholder | Significado |
|---|---|
| `{REF}` | `` `dtlk-sandbox`.micracao_alteryx.val_ref__<prefixo>__<tabela> `` (saída Alteryx materializada no Lake) |
| `{NEW}` | `` `dtlk-sandbox`.micracao_alteryx.<prefixo>__<tabela> `` (saída do notebook migrado) |
| `{CHAVE}` | Colunas da chave de negócio |
| `{GRUPO}` | Dimensão de quebra (ex.: `DATA_REF`) |

Regras gerais:
- **Tudo roda no Spark** — REF já ingerida no Lake (Fase B). Nunca comparar métrica calculada em engine diferente.
- Joins de comparação sempre **null-safe**: `r.k <=> n.k`.
- Nomear cada query executada no relatório pelo código (Q-VOL, Q-ANTIJOIN, ...) com o resultado.

---

## Nível 1 — Volumetria

```sql
-- Q-VOL: total
SELECT 'REF' AS lado, COUNT(*) AS linhas FROM {REF}
UNION ALL
SELECT 'NEW', COUNT(*) FROM {NEW};

-- Q-VOL-GRUPO: por dimensão (localiza ONDE a diferença mora)
SELECT COALESCE(r.grp, n.grp) AS grupo,
       r.linhas AS ref, n.linhas AS new,
       COALESCE(n.linhas, 0) - COALESCE(r.linhas, 0) AS diff
FROM (SELECT {GRUPO} AS grp, COUNT(*) AS linhas FROM {REF} GROUP BY {GRUPO}) r
FULL OUTER JOIN
     (SELECT {GRUPO} AS grp, COUNT(*) AS linhas FROM {NEW} GROUP BY {GRUPO}) n
  ON r.grp <=> n.grp
ORDER BY ABS(COALESCE(n.linhas, 0) - COALESCE(r.linhas, 0)) DESC;
```

## Nível 2 — Schema

```sql
-- Q-SCHEMA: diff de colunas e tipos (lower() separa "só case" de "coluna outra")
WITH r AS (
  SELECT lower(column_name) AS coluna, column_name AS nome_ref, data_type AS tipo_ref
  FROM `dtlk-sandbox`.information_schema.columns
  WHERE table_schema = 'micracao_alteryx' AND table_name = '<nome_tabela_ref>'
), n AS (
  SELECT lower(column_name) AS coluna, column_name AS nome_new, data_type AS tipo_new
  FROM `dtlk-sandbox`.information_schema.columns
  WHERE table_schema = 'micracao_alteryx' AND table_name = '<nome_tabela_new>'
)
SELECT COALESCE(r.coluna, n.coluna) AS coluna,
       r.nome_ref, n.nome_new, r.tipo_ref, n.tipo_new,
       CASE WHEN r.coluna IS NULL THEN 'SÓ NEW'
            WHEN n.coluna IS NULL THEN 'SÓ REF'
            WHEN r.tipo_ref <> n.tipo_new THEN 'TIPO DIFERE'
            WHEN r.nome_ref <> n.nome_new THEN 'CASE DIFERE'
            ELSE 'OK' END AS status
FROM r FULL OUTER JOIN n ON r.coluna = n.coluna
ORDER BY status;
```

A mesma query, apontada para a tabela de origem, cobre o check transversal "**toda coluna referenciada existe no schema real**" — conferir cada coluna citada nos `spark.sql` do fluxo contra o resultado.

## Nível 3 — Perfil de colunas

```sql
-- Q-PERFIL-NUM: uma execução por coluna numérica
SELECT 'REF' AS lado, COUNT(*) AS linhas, COUNT({COL}) AS nao_nulos,
       COUNT(DISTINCT {COL}) AS distintos,
       SUM({COL}) AS soma, MIN({COL}) AS minimo, MAX({COL}) AS maximo
FROM {REF}
UNION ALL
SELECT 'NEW', COUNT(*), COUNT({COL}), COUNT(DISTINCT {COL}),
       SUM({COL}), MIN({COL}), MAX({COL})
FROM {NEW};

-- Q-PERFIL-STR: vazios ≠ nulos é proposital (o Alteryx distingue '' de null)
SELECT 'REF' AS lado, COUNT({COL}) AS nao_nulos, COUNT(DISTINCT {COL}) AS distintos,
       SUM(CASE WHEN {COL} = '' THEN 1 ELSE 0 END) AS vazios,
       SUM(CASE WHEN {COL} <> trim({COL}) THEN 1 ELSE 0 END) AS com_espacos,
       SUM(length({COL})) AS soma_comprimentos
FROM {REF}
UNION ALL
SELECT 'NEW', COUNT({COL}), COUNT(DISTINCT {COL}),
       SUM(CASE WHEN {COL} = '' THEN 1 ELSE 0 END),
       SUM(CASE WHEN {COL} <> trim({COL}) THEN 1 ELSE 0 END),
       SUM(length({COL}))
FROM {NEW};

-- Q-PERFIL-DATA: MIN/MAX/DISTINCT por coluna de data
```

Interpretação rápida: `soma` difere com `nao_nulos` igual → valor (§3 do diagnóstico); `nao_nulos` difere → nulls novos (ToNumber/cast); `vazios` difere → `''`×null; `com_espacos` difere → cleansing/collation.

## Nível 4 — Chaves

```sql
-- Q-UNICIDADE: a chave é chave mesmo?
SELECT COUNT(*) AS linhas, COUNT(DISTINCT {CHAVE}) AS chaves FROM {NEW};

-- Q-ANTIJOIN: presentes em REF, ausentes em NEW (rodar também no sentido inverso)
SELECT COUNT(*) AS ausentes_em_new
FROM {REF} r LEFT ANTI JOIN {NEW} n ON r.k1 <=> n.k1 AND r.k2 <=> n.k2;

SELECT r.* FROM {REF} r
LEFT ANTI JOIN {NEW} n ON r.k1 <=> n.k1 AND r.k2 <=> n.k2
LIMIT 20;

-- Q-ANTIJOIN-NORM: se zerar com chave normalizada, a causa é case/espaço (collation)
SELECT COUNT(*) AS ausentes_apos_normalizar
FROM {REF} r LEFT ANTI JOIN {NEW} n
  ON upper(trim(r.k1)) <=> upper(trim(n.k1));
```

## Nível 5 — Linha a linha (checksum)

`concat_ws` **ignora argumentos null silenciosamente** — por isso o `coalesce` de cada coluna é obrigatório, com marcador distinto de string vazia:

```sql
-- Q-HASH: normalização padrão — decimais com escala fixa, timestamps formatados, strings cruas
WITH ref_h AS (
  SELECT {CHAVE},
         md5(concat_ws('\u241F',
             coalesce(cast(col_str                          AS string), '§NULL§'),
             coalesce(cast(cast(col_dec AS decimal(38,6))   AS string), '§NULL§'),
             coalesce(date_format(col_ts, 'yyyy-MM-dd HH:mm:ss'),       '§NULL§')
         )) AS h
  FROM {REF}
), new_h AS (
  SELECT {CHAVE}, md5(concat_ws('\u241F', /* mesmas colunas, mesma ordem */)) AS h
  FROM {NEW}
)
SELECT COALESCE(r.k1, n.k1) AS k1,
       CASE WHEN r.h IS NULL THEN 'SÓ NEW'
            WHEN n.h IS NULL THEN 'SÓ REF'
            WHEN r.h <> n.h  THEN 'DIFERE' END AS status
FROM ref_h r FULL OUTER JOIN new_h n ON r.k1 <=> n.k1
WHERE r.h IS NULL OR n.h IS NULL OR r.h <> n.h
LIMIT 100;

-- Q-DIFF-COL: para as chaves com status DIFERE, achar QUAL coluna diverge
SELECT r.k1, 'COL_X' AS coluna, r.col_x AS ref, n.col_x AS new
FROM {REF} r JOIN {NEW} n ON r.k1 <=> n.k1
WHERE NOT (r.col_x <=> n.col_x)
LIMIT 20;
-- repetir por coluna (ou gerar via UNION ALL programático a partir do schema)
```

Em volumes grandes, `xxhash64` no lugar de `md5` é mais barato.

### Normalização progressiva (Fase D.5)

Reexecutar Q-HASH acrescentando uma normalização por vez. A primeira que faz o hash bater nomeia a família da causa:

| Passo | Normalização acrescentada | Se bater, a causa é |
|---|---|---|
| 0 | nenhuma (cru) | — |
| 1 | `trim()` nas strings | Espaços → collation / Data Cleansing |
| 2 | + `upper()` | Case → collation |
| 3 | + `round(col, s)` nos decimais | Truncamento × arredondamento |
| 4 | + `cast(ts AS date)` | Hora / timezone |
| nenhum | — | Q-DIFF-COL coluna a coluna |

---

## Queries de confirmação (Fase D)

```sql
-- Q-FANOUT: chave duplicada no lado direito do join (linhas a mais)
SELECT {CHAVE_JOIN}, COUNT(*) AS ocorrencias
FROM <lado_direito_do_join>
GROUP BY {CHAVE_JOIN}
HAVING COUNT(*) > 1
ORDER BY ocorrencias DESC
LIMIT 20;

-- Q-NULLKEY: nulls na chave de join (explica volumetria de L/R e matches perdidos)
SELECT SUM(CASE WHEN {CHAVE_JOIN} IS NULL THEN 1 ELSE 0 END) AS chaves_nulas, COUNT(*) AS total
FROM <lado>;

-- Q-DUPEXATA: duplicatas de linha inteira em REF (se existem e NEW as perdeu → UNION sem ALL)
WITH h AS (SELECT md5(concat_ws('\u241F', /* todas as colunas com coalesce */)) AS hash FROM {REF})
SELECT COUNT(*) - COUNT(DISTINCT hash) AS duplicatas_exatas FROM h;

-- Q-PERIODO: formato de parâmetro temporal ('6' vs '06')
SELECT 'REF' AS lado, DATA_REF, COUNT(*) FROM {REF} GROUP BY DATA_REF
UNION ALL
SELECT 'NEW', DATA_REF, COUNT(*) FROM {NEW} GROUP BY DATA_REF
ORDER BY DATA_REF, lado;
```

---

## Instrumentação de checkpoint (Fase D — modo diagnóstico)

Trabalhar em cópia `_diag_<notebook>` dentro de `PASTA_FLUXO/validacao/` — nunca no notebook de produção. Cada `count()` dispara computação: usar somente durante o diagnóstico.

```python
# --- célula temporária no topo da cópia _diag ---
_CK = []

def ck(df, tools, nome):
    """Checkpoint: registra volumetria e schema após um bloco @alteryx."""
    n = df.count()
    _CK.append({"tools": tools, "bloco": nome, "linhas": n, "schema": df.dtypes})
    print(f"[CK] tools={tools} | {nome} | linhas={n}")
    return df

# uso — imediatamente após cada bloco, com os MESMOS tool_ids da anotação @alteryx:
# df_vigentes = ck(df_vigentes, "42,43", "filtro_vigentes")
```

```python
# --- célula final: consolidado para confronto com o log do Alteryx ---
print(f"{'tools':<12} {'bloco':<40} {'linhas':>12}")
for c in _CK:
    print(f"{c['tools']:<12} {c['bloco']:<40} {c['linhas']:>12}")
```

Confronto com o log do Alteryx:
1. Extrair do log os pares **ToolID → registros de saída** (o texto varia por versão/idioma — ex.: "records were output" / "registros"; interpretar com flexibilidade e montar a tabela).
2. Casar cada checkpoint com a contagem esperada da(s) tool(s) do bloco, na ordem topológica do DAG.
3. **O primeiro par esperado ≠ observado é o bloco culpado** → reportar seus ToolIDs e aplicar as queries de confirmação do sintoma.
4. Gravar a tabela esperado × observado em `PASTA_FLUXO/validacao/checkpoints.md`.
