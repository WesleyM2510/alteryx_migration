---
name: alteryx-translation-validator
description: Ative para validar a EQUIVALÊNCIA SEMÂNTICA E DE DADOS entre o fluxo Alteryx original (.yxmd) e o migrado — se produzem o mesmo resultado. Gatilhos: 'os dados batem com o Alteryx?', 'reconcilia esse fluxo', 'por que o resultado diverge?', 'valida a tradução', 'a contagem não confere', relato de divergência entre Alteryx e Databricks. Reconciliação em 5 níveis (volumetria→schema→perfil→chaves→hash) com diagnóstico localizado por ToolID. Integra o Lakebridge Reconcile para reconciliar fonte legada (swap1478_pl) na Fase B. Roda após a alteryx-flow-validator aprovar a estrutura.
---

# Skill: alteryx-translation-validator

## Escopo

Validar a **equivalência semântica e de dados** entre o fluxo Alteryx original (.yxmd) e o código migrado. Complementa — não substitui — a `alteryx-flow-validator`:

| Skill | Pergunta que responde |
|---|---|
| `alteryx-flow-validator` | O código migrado segue os padrões do projeto? (estrutura, nomenclatura, parâmetros) |
| `alteryx-translation-validator` | O código migrado **produz o mesmo resultado** que o Alteryx? (semântica + dados) |

Executar:
- APÓS a migração e a validação estrutural, ANTES do aceite do fluxo
- SEMPRE que houver relato de divergência entre resultado Alteryx e Databricks

Entrega um veredito por fluxo (APROVADO | APROVADO COM RESSALVAS | REPROVADO) com cada divergência **localizada por ToolID** (qual tool do Alteryx originou o problema) e por posição no código (notebook:célula ou arquivo:linha).

## Pre-requisitos

  readAssetById(assetType="file", assetId="/Workspace/Shared/Engineering/Migracao_Alteryx/AGENTS.md")

Ler também, do fluxo em validação:
- O `.yxmd` original
- `inventario_tools.md` — inventário de tools e DAG (se existir)
- `mapa_de_regras.md` — mapeamento ToolID → arquivo:linha / notebook:célula (se existir)
- Tabela Delta ``dtlk-sandbox`.micracao_alteryx.fontes_origem` — ÚNICO controle centralizado de fontes. Regra canônica: [../_shared/fontes-origem.md](../_shared/fontes-origem.md)
- [reconcile-lakebridge.md](reconcile-lakebridge.md) — **somente** se o fluxo tem fonte substituída (4.10) vinda de `swap1478_pl` e o Reconcile está configurado no ambiente

### [OBRIGATÓRIO] Validação de Fontes de Origem

Antes de iniciar a Fase A, verificar:
- [ ] O notebook possui `# ORIGEM ALTERYX:` em cada fonte da Célula 5?
- [ ] Os caminhos documentados correspondem aos inputs reais do .yxmd (conferir ToolIDs)?
- [ ] A tabela `fontes_origem` contém registros para este fluxo (`SELECT * FROM fontes_origem WHERE fluxo = '<fluxo>'`)?
- [ ] Sem duplicatas: `fluxo` + `tool_id` é único?
- [ ] `existe_lake` foi verificado (não marcado 'NÃO' sem checar padrão `source_excel__<nome>__<guia>`) e não contém `PARCIAL`?

Se alguma fonte não estiver documentada com caminho de origem → registrar como ERRO bloqueante.
Se registros duplicados na tabela → registrar como ERRO e corrigir (DELETE do duplicado).

Se `inventario_tools.md`/`mapa_de_regras.md` não existirem, reconstruir o mapa mínimo ToolID → bloco via grep das anotações `@alteryx` nos notebooks. Se nem as anotações existirem → registrar em `PENDENCIAS.md`; a reconciliação (Fase C) segue normalmente, mas o diagnóstico por ToolID (Fase D) fica limitado a assinaturas de sintoma.

---

## Ao receber o pedido de validação

Perguntar:

1. **Qual fluxo (pasta) validar?**
2. **Parâmetros de referência** (`pr_ano`, `pr_mes`, ...) de uma execução Alteryx **concluída com sucesso**?
3. **Onde está a saída de referência (REF)** produzida pelo Alteryx? (tabela destino no SQL Server, arquivo exportado, .yxdb)
4. **O log de execução do Alteryx está disponível?** (contém a contagem de registros por tool — habilita o diagnóstico preciso da Fase D)
5. **Qual a chave de negócio de cada tabela final?** (necessária para os Níveis 4-5; se desconhecida, inferir candidatas — combinação cujo `COUNT DISTINCT` = `COUNT(*)` — e confirmar com o usuário)
6. **O fluxo tem fonte substituída (4.10)?** Se sim, e havendo Reconcile configurado para `swap1478_pl`, a reconciliação de fontes da Fase B pode ser automatizada — ver [reconcile-lakebridge.md](reconcile-lakebridge.md). Sem Reconcile, segue manual: o caminho manual nunca é bloqueado por indisponibilidade da ferramenta.

---

## Fases

### Fase A — Auditoria semântica estática (pré-execução)

Aplicar [checklist-semantico.md](checklist-semantico.md) ao código migrado, tool a tool:

1. Para cada tool ativa do inventário, localizar o bloco correspondente pela anotação `@alteryx`.
2. Verificar os pontos do checklist aplicáveis ao plugin da tool. Registrar `[OK]` / `[ERRO]` / `[N/A]` com evidência (notebook:célula ou arquivo:linha).
3. Verificar os **checks transversais** (parâmetros, backticks, `UNION ALL`, colunas vs schema real, fontes substituídas).
4. Tools sem lógica de dados (Browse, Comment, Tool Container, Explorer Box) → `[N/A]`.

`[ERRO]` na Fase A já caracteriza tradução incorreta. É permitido corrigir antes de seguir para as fases de execução — mas registrar tudo no relatório.

### Fase B — Preparação da execução pareada

Divergência só é atribuível à tradução se os dois lados leram **os mesmos insumos com os mesmos parâmetros**. Antes de comparar:

- [ ] Identificar a última execução Alteryx bem-sucedida do período de referência (data/hora).
- [ ] Confirmar que as fontes de entrada **não foram recarregadas** entre a execução Alteryx e a execução do notebook. Se foram → escolher um período fechado estável. Divergência com fonte alterada é **espúria** — descartar antes de culpar a tradução.
- [ ] Materializar REF no Lake como `val_ref__<tabela>` (staging de validação), usando o mesmo mecanismo de leitura do legado já adotado pelo projeto; se REF for arquivo, ingerir. **Toda comparação é calculada no Spark** — nunca metade em cada engine (formatação/precisão de engines diferentes gera falso positivo).
- [ ] Se o fluxo tem **fonte substituída** (regra 4.10 do migrator), **reconciliar primeiro as fontes**: volumetria e agregados da tabela legada vs equivalente no Lake, no período. Equivalentes com filtro ou transformação embutida (ex.: `int_planejamento__producao_emprestimos` = `producao_det` com `CON_COD_SIS <> 80` e colunas renomeadas) são suspeitos de primeira ordem. Dois caminhos, mesmo resultado exigido:
  - **Manual** (padrão, sempre disponível): queries de [queries-reconciliacao.md](queries-reconciliacao.md) apontadas para legado × Lake.
  - **Lakebridge Reconcile** (quando configurado): modos `schema` + `aggregates`, config derivada dos mapeamentos do AGENTS.md — ver [reconcile-lakebridge.md](reconcile-lakebridge.md). Anotar o `recon_id` no relatório. Não usar `row`/`data`/`all` sem as `transformations` de normalização declaradas: esses modos calculam hash no lado da origem, e hash cruzando engines reintroduz exatamente o falso positivo que a regra acima evita.
  - **Fonte divergente = pare.** A causa não é a tradução; corrigir a fonte antes de seguir para a Fase C.
- [ ] Executar os notebooks do fluxo via `_executor`, com os mesmos parâmetros da execução de referência.

Tabelas `val_ref__*` são temporárias: **dropar após o veredito** (Fase E).

### Fase C — Reconciliação de dados (5 níveis, com gate)

Aplicar os templates de [queries-reconciliacao.md](queries-reconciliacao.md) a cada **tabela final** (onde existe REF). Intermediárias `int_` são validadas por volumetria de checkpoint na Fase D — e por reconciliação direta apenas quando o Alteryx gravava um `.yxdb` equivalente.

**Não avançar de nível com o anterior em ERRO.** Corrigir e reentrar no nível que falhou.

| Nível | O que compara | Tolerância |
|---|---|---|
| 1 — Volumetria | `COUNT(*)` total e por grupo (`DATA_REF`, dimensões-chave) | 0 |
| 2 — Schema | Colunas, tipos, nulidade | 0 (diferença documentada e aceita = ressalva) |
| 3 — Perfil de colunas | Numéricas: SUM / MIN / MAX / não-nulos / DISTINCT. Strings: DISTINCT, não-nulos, vazios (`''`), soma de comprimentos. Datas: MIN / MAX / DISTINCT | Contagens: 0. Somas decimal: abs ≤ 0,01 **e** rel ≤ 0,001% (configurável) |
| 4 — Chaves | `COUNT DISTINCT` da chave + anti-join nos dois sentidos (amostrar 20) | 0 |
| 5 — Linha a linha | Hash por linha sobre colunas normalizadas + FULL OUTER JOIN pela chave; diff coluna a coluna nas divergentes | 0 após normalização declarada |

Diferença dentro de tolerância só vira **RESSALVA** se tiver **causa nomeada** (ex.: truncamento vs arredondamento de Fixed Decimal, tool_id identificado). Tolerância não é licença para diferença inexplicada.

**Esta fase não usa Lakebridge Reconcile.** REF e NEW já estão os dois no Spark, e os cinco níveis medem o que o Reconcile não mede — `''` × null, strings com espaço à direita, soma de comprimentos. Essas medidas não são conferência: são a assinatura de sintoma que a Fase D consome.

### Fase D — Diagnóstico de divergência (localizar a tool)

Objetivo: transformar "a contagem não bate" em "**a divergência nasce na tool 42 (Join), notebook 001 célula 7, por chave não única no lado direito**".

1. **Com log do Alteryx** (caminho preferencial): extrair do log os pares ToolID → contagem de registros de saída (o texto exato varia por versão/idioma — interpretar com flexibilidade). Instrumentar o notebook em **modo diagnóstico** (snippet em [queries-reconciliacao.md](queries-reconciliacao.md)): após cada bloco anotado, registrar contagem e schema. Percorrer o DAG em ordem topológica comparando esperado vs observado. **O primeiro checkpoint divergente aponta o bloco — e seus ToolIDs — onde a divergência nasce.**
2. **Sem log**: bissecção — instrumentar os pontos médios do DAG e estreitar até o bloco; combinar com as assinaturas de sintoma de [diagnostico-divergencias.md](diagnostico-divergencias.md).
3. Identificado o bloco, aplicar as **queries de confirmação** do catálogo de sintomas para nomear a causa raiz (fan-out de join, `UNION` deduplicando, branch F sem `IS NULL`, collation, etc.).
4. **Erro de tipo/schema**: mesma varredura, comparando schemas por checkpoint. Reportar o ToolID do primeiro ponto em que o tipo/coluna diverge do esperado.
5. **Normalização progressiva** (quando o Nível 5 diverge): recalcular o hash normalizando em etapas — (a) `trim`, (b) `upper`, (c) `round` de decimais, (d) data sem hora. A primeira normalização que faz o hash bater **nomeia a família da causa** (espaços → collation/cleansing; case → collation; round → truncamento×arredondamento; hora → timezone).

Regras do diagnóstico:
- Uma divergência raiz gera N sintomas a jusante. **Corrigir sempre a divergência mais a montante primeiro**, reexecutar e reconciliar de novo. Não caçar sintomas derivados.
- Instrumentação (`count()` por bloco) tem custo de execução. Usar apenas em modo diagnóstico, sobre cópia `_diag_<notebook>` em `PASTA_FLUXO/validacao/` — nunca deixar instrumentação no notebook de produção.
- O diagnóstico **localiza e nomeia**; a correção segue as regras do migrator (fidelidade ao .yxmd) e reentra na Fase C a partir do nível que falhou.

### Fase E — Relatório e veredito

Gravar `PASTA_FLUXO/validacao/relatorio_traducao.md` no formato abaixo. Encerramento — captura de descobertas conforme a regra canônica **[../_shared/loop-feedback.md](../_shared/loop-feedback.md)**:

1. Divergência recorrente nova → proposta com tag `[traducao]`, avaliada pelos três critérios (reproduzível, verificável, geral) antes de encaminhar.
2. Pendências sem resolução → `PENDENCIAS.md` com ToolID, sintoma e pergunta em aberto.
3. **Dropar** as tabelas `val_ref__*` do fluxo.
4. Remover/descartar cópias `_diag_*`.
5. Se houve reconciliação de fontes via Reconcile: registrar `recon_id` e versão do Lakebridge no relatório. **Não dropar** os metadados do Reconcile — são a trilha de auditoria da fonte, e sobrevivem ao fluxo.

Critérios de veredito:
- **APROVADO** — Fase A sem ERRO; Níveis 1-5 OK.
- **APROVADO COM RESSALVAS** — diferenças dentro de tolerância, com causa nomeada e aceite explícito do usuário (ex.: amostragem aleatória irreprodutível, arredondamento aceito pelo negócio).
- **REPROVADO** — qualquer ERRO não resolvido em qualquer fase.

---

## Formato do Relatório

```text
=== RELATÓRIO DE VALIDAÇÃO DE TRADUÇÃO ===
Fluxo: <nome>  |  Data: <data>
Período de referência: pr_ano=<> pr_mes=<> ...  |  REF: <origem da referência>
Fontes congeladas: SIM/NÃO (<observação>)
Log Alteryx disponível: SIM/NÃO
Reconciliação de fontes: MANUAL | RECONCILE (recon_id=<id>, lakebridge=<versão>) | N/A (sem fonte substituída)

FASE A — SEMÂNTICA ESTÁTICA
[OK]   tool_id=12 Join   | L/J/R conferidos; Right_ replicado                | 001 célula 7
[ERRO] tool_id=27 Union  | SQL usa UNION (deduplica); Alteryx não deduplica  | 001 célula 9
       Correção: trocar por UNION ALL

FASE C — RECONCILIAÇÃO               REF           NEW           DIFF
Nível 1  COUNT(*) <tabela>           1.254.310     1.254.273     -37      [ERRO]
Nível 3  SUM(PDU_VLR_LIB)            84.123,45     84.123,41     -0,04    [RESSALVA]

FASE D — DIAGNÓSTICO
[ERRO] <tabela> | volumetria -37 | tool_id=42 (Join) | 001 célula 7
       Causa raiz: chaves com espaço à direita casam no SQL Server (collation) e não no Spark
       Evidência: 37 chaves no anti-join; todas com length(col) <> length(trim(col))
       Correção sugerida: ver checklist-semantico.md §Collation
[RESSALVA] <tabela> | SUM -0,04 | tool_id=8 (Select, Fixed Decimal) | 001 célula 5
       Causa: truncamento (Alteryx) vs arredondamento (CAST) | Aceite: <usuário/data>

VEREDITO: REPROVADO
Resumo: XX checks | XX ok | XX ressalvas | XX erros
Próximos passos: <correções, na ordem mais-a-montante-primeiro>
```

---

## Reference Files

- [checklist-semantico.md](checklist-semantico.md) — Fase A: catálogo completo dos cenários de falha de tradução, em forma de verificação
- [diagnostico-divergencias.md](diagnostico-divergencias.md) — Fase D: sintoma → tools suspeitas → causa → query de confirmação
- [queries-reconciliacao.md](queries-reconciliacao.md) — Fases C/D: templates SQL de reconciliação e instrumentação de checkpoint
- [reconcile-lakebridge.md](reconcile-lakebridge.md) — Fase B: reconciliação automatizada de fonte legada (`swap1478_pl`) × Lake, config, limites e checklist de adoção

## Caminhos e Convenções

| Referência | Valor |
|---|---|
| Staging de referência | `` `dtlk-sandbox`.micracao_alteryx.val_ref__<prefixo>__<tabela> `` — temporária, dropar na Fase E |
| Artefatos de validação | `PASTA_FLUXO/validacao/` (`relatorio_traducao.md`, `checkpoints.md`) |
| Cópias instrumentadas | `PASTA_FLUXO/validacao/_diag_<notebook>` |
| Tolerância padrão (somas decimal) | abs ≤ 0,01 e rel ≤ 0,001% — ajustável por fluxo com registro no relatório |
| Config do Reconcile (fonte de verdade) | `RAIZ_PROJETO/_reconcile/config/` — versionada; `.lakebridge/` é só destino de deploy |
| Metadados do Reconcile | `` `dtlk-sandbox`.`reconcile_meta` `` — schema próprio, **nunca** em `micracao_alteryx` |

> **Exceção a R1.** O Reconcile grava sua configuração em `<USER_WORKSPACE_HOME>/.lakebridge/`, fora de `RAIZ_PROJETO`. Exceção autorizada apenas para o deploy dessa config; editar direto lá = perda garantida na próxima reinstalação. Registrar a exceção no AGENTS.md antes de adotar, sob pena de um agente seguindo R1 à risca abortar a execução.
