# Checklist Semântico — Cenários de Falha de Tradução

## When to Use

Fase A da validação. Estende `alteryx-flow-migrator/semantica-alteryx-spark.md` transformando cada armadilha em **verificação auditável**, e adiciona cenários não cobertos lá (collation, casts/ANSI, timezone, `UNION ALL`, `Right_`, tools sem tradução direta). Ao descobrir armadilha nova, atualizar **os dois** arquivos.

Para cada tool ativa do inventário: localizar o bloco (`@alteryx tool_id=...`), aplicar os checks do plugin, registrar `[OK]`/`[ERRO]`/`[N/A]` com evidência.

---

## Checks transversais (aplicar a todo fluxo, sempre)

- [ ] **Parâmetros com aspas e zero-pad**: `ANO = '{args.get("pr_ano")}'` (sem aspas → `PARSE_SYNTAX_ERROR`); `pr_mes` no formato da comparação (`'06'`, nunca `'6'`, quando `DATA_REF = 'YYYYMM'`).
- [ ] **Backticks**: `` `dtlk-sandbox` `` sempre com crases; colunas com espaço/acento idem.
- [ ] **Toda coluna referenciada existe no schema real** — conferir via `information_schema.columns` (query em queries-reconciliacao.md). Cobre de forma automática os "Erros Recorrentes" do AGENTS.md (`COD_PROD_OPER`, `NUM_CONTRATO` em `rentabilidade_cartao`, etc.).
- [ ] **`UNION ALL`, nunca `UNION`**: o `UNION` do SQL deduplica; o Union do Alteryx **não**. Grep por `UNION` sem `ALL` em todo o fluxo.
- [ ] **Nenhum `monotonically_increasing_id()`** como substituto de ordem do Alteryx (não replica a ordem — se aparece, é ERRO; sem chave determinística real → PENDÊNCIA).
- [ ] **Branch F de Filter** implementado como `NOT(cond) OR (cond IS NULL)` — nunca `NOT(cond)` puro (perde as linhas com null).
- [ ] **Join com colunas homônimas**: renomeio `Right_*` do Alteryx replicado (o Alteryx prefixa automaticamente as colunas duplicadas do lado direito; o schema de saída deve bater).
- [ ] **Fontes substituídas (4.10)**: para cada substituição, conferir se o equivalente no Lake carrega filtro ou transformação embutida (`WHERE`, renames, `DATA_REF` derivado). Se sim, a semântica da substituição precisa estar declarada e validada na Fase B.
- [ ] **Strings vindas do SQL Server**: decisão de collation registrada (ver §Collation).

---

## Tool a tool

### Join
- [ ] Quais saídas (L / J / R) estão conectadas no .yxmd? Cada uma conectada tem implementação (J = `INNER`; L/R = `LEFT ANTI` / `RIGHT ANTI`)?
- [ ] Chave é única no lado que deveria ser único? (fan-out → linhas a mais; query de confirmação no diagnóstico)
- [ ] Tipos das chaves idênticos nos dois lados — Spark faz cast implícito em `string = int` e pode casar/deixar de casar de forma diferente do Alteryx (que exige tipos compatíveis).
- [ ] Nulls nas chaves: não casam em nenhum dos engines — mas contá-los explica a volumetria de L/R.
- [ ] Fluxo original era **In-DB** (join executava no SQL Server, collation CI)? → risco de perda de matches por case/trailing space no Spark.

### Union
- [ ] `UNION ALL` (ver transversal).
- [ ] Config **byName vs byPosition** respeitada; campos ausentes → null (`unionByName(allowMissingColumns=True)` quando byName com schemas distintos).
- [ ] Por posição: tipos por coluna compatíveis (cast implícito do Spark pode mascarar desalinhamento de colunas).

### Unique
- [ ] `row_number()` particionado **exatamente** pelos campos da config (a mais → dedup insuficiente; a menos → dedup excessivo).
- [ ] `ORDER BY` determinístico documentado (o Alteryx mantém o primeiro na ordem de entrada). Sem chave de ordem → PENDÊNCIA, não inventar.

### Filter
- [ ] Saídas T e F: quais conectadas; F com tratamento de null (ver transversal).
- [ ] Expressão convertida: `!=` → `<>`, funções Alteryx → SQL, precedência preservada em condições compostas.

### Formula
- [ ] `IIF` → `CASE WHEN` (incluindo aninhados).
- [ ] `Substring`: **0-based no Alteryx, 1-based no SQL** → `substring(col, pos+1, len)`.
- [ ] `IsNull` ≠ `IsEmpty`: `''` não é null — a distinção precisa sobreviver à tradução.
- [ ] Máscaras de data: `%Y-%m-%d` (Alteryx) → `yyyy-MM-dd` (Spark).
- [ ] `ToNumber`: Alteryx → `0` com warning; `CAST` no Spark → `null` (ou **erro**, com ANSI). Divergência 0×null tratada explicitamente e decisão documentada (`try_cast` + `coalesce(..., 0)` **somente** se replicar o Alteryx).
- [ ] Divisões: comportamento de divisor zero difere entre engines e entre modos ANSI → proteger com `NULLIF(den, 0)` ou `try_divide` e documentar a semântica esperada.
- [ ] `DateTimeNow()` / datas relativas a "hoje": ver §Ambiente (timezone).

### Select
- [ ] Deselects aplicados — colunas removidas não vazam para o schema final.
- [ ] Renames replicados (inclusive os implícitos de conflito).
- [ ] `Fixed Decimal` → `decimal(p,s)` com p/s corretos; **truncamento (Alteryx) vs arredondamento (CAST)** — se a diferença de centavos importa, replicar o truncamento e registrar.

### Summarize
- [ ] Campos de Group By exatos.
- [ ] `Count` vs `CountNonNull` → `count(*)` vs `count(col)`.
- [ ] `Concat`: separador **e ordem** — `collect_list` sem ordem determinística → PENDÊNCIA.
- [ ] `First` / `Last`: exigem ordem determinística explícita.
- [ ] `Sum` de coluna 100% nula → Spark retorna null; conferir consumo a jusante.

### Multi-Row Formula
- [ ] `Row-1:[Campo]` → `lag()` / `lead()` com `PARTITION BY` = Group By da tool.
- [ ] Ordem determinística obrigatória (armadilha nº 1).
- [ ] Config de linha inexistente (`Null` / `0` / `Closest Valid Row`) replicada — `lag(col, 1, default)` muda o resultado.

### Cross Tab
- [ ] `pivot` com **valores fixados** — sem lista fixa, as colunas variam por período e o schema fica instável.
- [ ] Sanitização de nomes do Alteryx (especiais → `_`) e ordenação das colunas replicadas.
- [ ] Colisão pós-sanitização (dois valores distintos virando a mesma coluna) verificada.
- [ ] Método de agregação da config (Sum/First/Concat...) correto.

### Transpose
- [ ] Key fields vs data fields corretos no `stack()`/unpivot.
- [ ] Unpivot exige colunas do **mesmo tipo** — cast prévio quando misturam.

### Append Fields
- [ ] Cross join intencional; config de limite de segurança (Allow/Warn/Error) considerada.
- [ ] Volumetria esperada = |L| × |R| — conferir na Fase C.

### Find Replace
- [ ] Modo append vs replace conforme config.
- [ ] `Case Insensitive` da config replicado.
- [ ] Comportamento com múltiplos matches definido.

### Data Cleansing
- [ ] Macro expandida **somente** nos checkboxes marcados (trim, null→?, remoção de caracteres, case). Limpeza não marcada aplicada = alteração de dados = ERRO.

### Text to Columns
- [ ] Split em **colunas** vs em **linhas** (`explode`) — semânticas diferentes.
- [ ] `split()` do Spark usa **regex**: delimitadores como `.` `|` `\` precisam de escape.
- [ ] Nº de colunas + política da coluna "extra"; comportamento com string vazia conferido.

### Dynamic Rename / Dynamic Select
- [ ] Schema dinâmico congelado em decisão explícita e documentada (alto risco de divergência).

### Sample / Record ID / Tile / Running Total / Sort
- [ ] `First/Last/Skip N`: ordem determinística obrigatória.
- [ ] Amostragem **aleatória**: irreprodutível por natureza → validar só volumetria e distribuição; RESSALVA permanente no relatório.
- [ ] `Record ID`: depende de ordem; se o ID é apenas interno (join do fluxo consigo mesmo), qualquer ordem **estável** serve — documentar.
- [ ] `Tile`: método da config define a tradução (Equal Records → `ntile`; demais métodos → mapear explicitamente).
- [ ] `Running Total`: `sum() over (partition by ... order by ... rows unbounded preceding)`.
- [ ] `Sort` isolado: em Spark, ordenação intermediária **não persiste** pelas transformações seguintes — a ordem deve viver no `OVER (ORDER BY ...)` da tool consumidora, não num sort solto.

### Generate Rows
- [ ] `sequence()` / `explode` com limites conferidos — off-by-one na condição do loop (inclusivo vs exclusivo).

### RegEx
- [ ] Flavor **Perl/Boost (Alteryx) vs Java (Spark)**: escapes, classes, lazy, grupos — testar o padrão traduzido contra amostra real antes de aprovar.

### Block Until Done
- [ ] Vira dependência de ordem entre notebooks — conferida no `_executor`.

### Interface tools (Analytic App)
- [ ] Parâmetros do app → widgets `pr_*`; defaults do app documentados.

---

## Tools sem tradução direta (exigem decisão registrada)

| Tool | O que verificar |
|---|---|
| **Família In-DB** (Connect/Filter/Join/Summarize In-DB, Data Stream In/Out) | A lógica original executava **no SQL Server** (collation CI, padding). Traduzir a semântica observada, não só o texto do SQL. Data Stream In/Out marca a fronteira de engine no fluxo original. |
| **Dynamic Input** | SQL montado em runtime → reconstruir com parâmetros `pr_*` e conferir o **SQL final gerado** (o log do Alteryx ajuda a recuperá-lo). |
| **Run Command** | Identificar o que executa: DELETE pré-carga → vira estratégia de carga do notebook; script externo → PENDÊNCIA. |
| **Download** | Chamada HTTP/API → PENDÊNCIA ou implementação dedicada aprovada pelo usuário. |
| **R / Python tool** | Código embutido → traduzir e validar isoladamente; se opaco → PENDÊNCIA. |
| **Email / Render / Layout / Report** | Não afetam dados → registrar como "não migrado consciente"; notificações vão para a camada de orquestração. |
| **Fuzzy Match** | Sem equivalente 1:1 no Spark → PENDÊNCIA obrigatória com proposta de abordagem. |

---

## §Collation e strings (SQL Server → Spark)

- SQL Server tipicamente compara com collation **case/accent-insensitive** e **ignora espaços à direita** em `=`. Spark é case-sensitive e não ignora espaço.
- Consequência: todo join, filtro, `GROUP BY` e `DISTINCT` sobre string vinda do legado pode divergir — mais ainda quando a lógica original era In-DB.
- Verificação: reexecutar o anti-join do Nível 4 com chaves normalizadas (`upper(trim(k))`); se as ausências zerarem, a causa é case/espaço.
- Decisão por coluna registrada no relatório: manter case-sensitive (fiel ao novo engine) **ou** normalizar (fiel ao resultado histórico) — nunca implícito.
- Preservar `''` ≠ null em toda a cadeia.

## §Ambiente de execução

- [ ] **Modo ANSI do cluster** identificado e registrado (habilitado por padrão nos runtimes recentes do Databricks). Com ANSI on: cast inválido, overflow de decimal e divisão por zero **lançam erro** — o Alteryx nunca lança, só avisa e segue. Onde a fidelidade exigir "null e segue": `try_cast` / `try_divide`.
- [ ] **Timezone**: `spark.sql.session.timeZone` (padrão UTC) vs hora local do servidor Alteryx. `DateTimeNow()` e filtros de "hoje" podem cair no dia errado — fixar timezone da sessão ou converter explicitamente, e registrar.
- [ ] **Tipos SQL Server → Spark** além da tabela do semantica: `datetime2`/`smalldatetime` → `timestamp`; `money` → `decimal(19,4)`; `bit` → `boolean`; `uniqueidentifier` → `string`.
