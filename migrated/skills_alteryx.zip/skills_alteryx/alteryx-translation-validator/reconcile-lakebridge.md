# Lakebridge Reconcile — Reconciliação de Fontes Legadas

## When to Use

**Fase B, e somente Fase B.** Reconciliar tabela do SQL Server legado (`swap1478_pl.dbo.*`) contra o equivalente já migrado no Lake, antes de atribuir qualquer divergência à tradução do fluxo.

Não usar nas Fases C, D ou E — ver §7 (o que o Reconcile não resolve).

Gate de entrada — usar Reconcile apenas se **todas** forem verdadeiras:

- [ ] O fluxo tem ao menos uma fonte substituída pela regra 4.10 (lê tabela do Lake no lugar de `swap1478_pl`)
- [ ] A tabela legada correspondente ainda existe e é consultável no SQL Server
- [ ] Existe connection de Lakehouse Federation configurada para `swap1478_pl` **e** o preview `remote_query` habilitado no workspace

Se qualquer item falhar → reconciliar as fontes com as queries manuais de [queries-reconciliacao.md](queries-reconciliacao.md), como sempre foi feito. O Reconcile é atalho, não requisito.

---

## 1. Por que Fase B e não Fase C

| Fase | Compara | Ferramenta correta | Motivo |
|---|---|---|---|
| B — fontes | SQL Server legado × tabela do Lake | **Reconcile** | Dois engines diferentes; é exatamente o caso de uso do Reconcile |
| C — resultado | `val_ref__*` × `<prefixo>__*` | Queries manuais | Ambos já no Spark; os 5 níveis são mais finos que o Reconcile e alimentam a Fase D |
| D — diagnóstico | checkpoint × log Alteryx | Instrumentação `ck()` | Reconcile não conhece ToolID |

A Fase C não ganha nada com o Reconcile. Os cinco níveis existentes cobrem o que ele faz (`schema` ≈ Nível 2, `aggregates` ≈ Nível 3, `data` ≈ Níveis 4-5) e ainda medem coisas que ele não mede — `''` × null, contagem de strings com espaço à direita, soma de comprimentos. Essas medidas não são conferência: são a assinatura de sintoma que a Fase D consome. Trocar por Reconcile perderia o diagnóstico e ganharia um dashboard.

---

## 2. Custo cruzado de engine — leia antes de escolher o modo

A Fase B determina que toda comparação seja calculada no Spark, "nunca metade em cada engine". O Reconcile **não** respeita isso nos modos `row`, `data` e `all`: ele empurra o cálculo de hash para o lado da origem. A evidência está na própria documentação — para Teradata, que não tem hash criptográfico portável em SQL puro, esses modos exigem instalar uma UDF **no servidor de origem**.

Consequência: hash calculado pelo SQL Server e hash calculado pelo Spark divergem por formatação de decimal, timestamp e string, mesmo com o dado idêntico. É a mesma classe de falso positivo que a regra da Fase B evita — e é por isso que o Reconcile publica um catálogo de `transformations` de normalização.

**Escolha de modo por risco:**

| Modo | Cross-engine? | Uso recomendado |
|---|---|---|
| `schema` | não | **Sempre.** Barato, sem risco, pega drift de tipo |
| `aggregates` | baixo | **Preferencial** para o conteúdo. Agregado é menos sensível a formatação que hash de linha |
| `row` | **sim** | Só com `transformations` declaradas e revisadas |
| `data` | **sim** | Idem, e só quando a chave for confiável |
| `all` | **sim** | Não usar em Fase B |

Regra prática: `schema` + `aggregates` respondem "a fonte substituída é equivalente?" com risco baixo. Se `aggregates` bater e ainda houver suspeita de divergência linha a linha, aí sim escalar para `data` — com as transformações da §5.

---

## 3. Conflito com R1 — resolver antes de instalar

O Reconcile grava a configuração em `<USER_WORKSPACE_HOME>/.lakebridge/`, fora de `RAIZ_PROJETO`. Isso viola R1 (todo caminho absoluto começa por `RAIZ_PROJETO`).

Resolução adotada:

- **Fonte de verdade** dos JSON: `RAIZ_PROJETO/_reconcile/config/` — versionada com o projeto
- `.lakebridge/` é **destino de deploy**, não local de edição. Editar lá = perda garantida na próxima reinstalação
- Registrar a exceção no AGENTS.md; sem isso, um agente seguindo R1 à risca aborta ao ver o caminho

Metadados e dashboard do Reconcile ficam em schema próprio — **`dtlk-sandbox`.`reconcile_meta`**, nunca em `micracao_alteryx`. O catálogo de migração não deve receber tabela de controle de ferramenta.

---

## 4. Instalação (uma vez por ambiente)

```bash
databricks labs install lakebridge
databricks labs lakebridge configure-reconcile
```

Não rodar `install-transpile`: não há transpiler de Alteryx no Lakebridge, e a etapa só adicionaria dependência de Java sem entregar nada.

Pré-requisitos que dependem de terceiros — levantar antes de prometer prazo:

| Item | Responsável | Observação |
|---|---|---|
| Connection de federation para `swap1478_pl` | Admin Databricks | Não precisa criar foreign catalog |
| Preview `remote_query` no workspace | Admin Databricks | Maior lead time; é config de workspace |
| `USE CONNECTION` na connection | Admin Databricks | — |
| `USE CATALOG` + `CREATE SCHEMA` em `dtlk-sandbox` | Admin Databricks | Para o schema `reconcile_meta` |
| Permissão de criar warehouse/cluster | Admin Databricks | Se negada: fixar `warehouse_id`/`cluster_id` no profile do CLI |

Se a connection de federation não puder ser criada, **pare aqui** — sem ela o Reconcile não funciona, e a reconciliação manual segue disponível.

<!-- Efeito colateral útil: a connection de federation responde de forma
     definitiva o critério `existe_lake` da regra 13 para toda fonte
     SQL Server — "consigo acessar via Databricks?" passa a ser um SELECT. -->

---

## 5. Config a partir dos mapeamentos do AGENTS.md

A tabela de mapeamentos confirmados do AGENTS.md **é** a configuração do Reconcile. A tradução é mecânica:

| No AGENTS.md | No Reconcile |
|---|---|
| `swap1478_pl.dbo.X` → `micracao_alteryx.Y` | `source_name` / `target_name` |
| Renome de coluna | `column_mapping` |
| `WHERE CON_COD_SIS <> 80` embutido no equivalente | `filters.source` |
| Coluna que não existe no Lake | `drop_columns` |
| Coluna derivada (`CONCAT(ano, LPAD(mes,2,'0'))`) | `transformations` |

Exemplo real — `producao_det` → `int_planejamento__producao_emprestimos`, que é o caso mais delicado do projeto porque carrega filtro **e** renomes **e** coluna derivada:

```json
{
  "source_name": "dbo.producao_det",
  "target_name": "int_planejamento__producao_emprestimos",
  "join_columns": ["COD_CONTRATO"],
  "filters": {
    "source": "CON_COD_SIS <> 80 AND DATA_REF = '{pr_ano}{pr_mes}'",
    "target": "ano = '{pr_ano}' AND mes = '{pr_mes}'"
  },
  "column_mapping": [
    { "source_name": "cod_contrato", "target_name": "COD_CONTRATO"   },
    { "source_name": "pro_dsc_gpr",  "target_name": "FAMILIA_PRODUTO" },
    { "source_name": "vl",           "target_name": "PDU_VLR_LIB"    },
    { "source_name": "vlr_con",      "target_name": "PDU_VLR_CON"    },
    { "source_name": "taxa_aa",      "target_name": "TAXA_ANUAL"     },
    { "source_name": "pro_cod_cla",  "target_name": "CON_COD_PRO"    }
  ],
  "drop_columns": ["CON_COD_SIS"],
  "transformations": [
    {
      "column_name": "DATA_REF",
      "source": "DATA_REF",
      "target": "CONCAT(ano, LPAD(mes, 2, '0'))"
    }
  ],
  "aggregates": [
    { "type": "count", "agg_columns": ["COD_CONTRATO"], "group_by_columns": ["DATA_REF"] },
    { "type": "sum",   "agg_columns": ["PDU_VLR_LIB"],  "group_by_columns": ["DATA_REF"] },
    { "type": "sum",   "agg_columns": ["PDU_VLR_CON"],  "group_by_columns": ["DATA_REF"] }
  ]
}
```

**Armadilhas desta config, todas já catalogadas nos Erros Recorrentes do AGENTS.md:**

- `pr_mes` com zero-pad (`'06'`, nunca `'6'`) — mesma regra dos parâmetros de notebook. Sem isso o filtro recorta período errado e a divergência resultante é espúria
- Lado origem filtra por `DATA_REF`; lado destino filtra por `ano`/`mes`. Filtro assimétrico é legítimo **aqui** porque os schemas diferem — mas exige a nota de justificativa, senão invalida o resultado sem avisar
- `CON_COD_SIS` em `drop_columns` porque não existe no Lake. Isso significa que o filtro `<> 80` **não é verificável pelo Reconcile** — é premissa, não conclusão. Registrar como tal
- Confirme a estrutura dos blocos de nível superior contra a saída do `configure-reconcile` da versão instalada; a config do Reconcile passou por simplificação de parâmetros em releases recentes

**Nome do arquivo** — respeitar exatamente a caixa usada na config, ou a execução falha em silêncio:

```
recon_config_mssql_<nome_da_connection>_<report_type>.json
```

---

## 6. Execução e leitura do resultado

```bash
# Degrau 1 — sempre primeiro
databricks labs lakebridge reconcile   # config *_schema.json

# Degrau 2 — conteúdo
databricks labs lakebridge reconcile   # config *_aggregates.json
```

Cada execução gera um `recon_id`. **Anotar no relatório da Fase E** — é a evidência de que a fonte foi conferida, e o que permite reabrir o detalhe no dashboard meses depois numa auditoria.

Leitura do resultado, em ordem:

| Resultado | Significado | Ação |
|---|---|---|
| `schema` OK, `aggregates` OK | Fonte substituída é equivalente no período | Seguir para Fase C; divergência posterior é da tradução |
| `schema` diverge | Drift de tipo entre legado e Lake | Neutralizar via `transformations` **ou** registrar como ressalva. Não seguir sem decidir |
| `aggregates` diverge | Equivalente do Lake **não** reproduz a fonte | **Pare.** Não é problema de tradução. Trata-se de erro na migração da fonte, ou de premissa errada sobre filtro/transformação embutida |
| `ReconciliationException` | Qualquer tabela falhou em qualquer dimensão | Isolar tabela a tabela; uma config ruim derruba a rodada inteira |

O terceiro caso é o mais valioso do Reconcile neste projeto: ele impede que horas sejam gastas caçando ToolID quando a divergência nasce na fonte substituída. Hoje isso é conferido à mão, por fluxo, repetidamente — e cada fluxo que reusa a mesma fonte repete o mesmo trabalho.

---

## 7. O que o Reconcile não resolve

Registrar no relatório para não criar falsa sensação de cobertura:

- **Não diagnostica por ToolID.** Ele diz que 37 linhas divergem, não que a tool 42 tem fan-out de join. As Fases C e D permanecem inteiramente manuais
- **Não faz normalização progressiva.** As `transformations` são fixas; não iteram para nomear a família da causa (§D.5)
- **Não cobre fonte que não seja banco.** Excel, TXT, `.yxdb` e compartilhamento de rede estão fora — e são fonte frequente nos fluxos Alteryx
- **Não cobre as tabelas sem equivalente no Lake** listadas no AGENTS.md (`rentabilidade_cartao`, `comissoes_ifrs`, `cadastro_contas`, ...). Sem alvo, não há reconciliação
- **Não substitui `val_ref__`.** A saída de referência do Alteryx continua sendo materializada e comparada no Spark
- **Falha é all-or-nothing.** O gate por nível da Fase C é mais fino que a exceção única do Reconcile

**Governança:** o Lakebridge é projeto Databricks Labs, distribuído AS-IS, sem SLA e sem canal de suporte da Databricks. Em ambiente regulado, isso precisa de aceite de risco registrado antes de o Reconcile virar parte de um gate de aprovação. Fixar a versão usada e registrar no relatório; as regras da ferramenta mudam entre releases.

---

## 8. Checklist de adoção

| # | Item | Responsável |
|---|---|---|
| 1 | Aceite de risco do uso de ferramenta AS-IS em gate de validação | Arquitetura / Risco |
| 2 | Connection de federation para `swap1478_pl` | Admin Databricks |
| 3 | Preview `remote_query` habilitado | Admin Databricks |
| 4 | Schema `dtlk-sandbox`.`reconcile_meta` criado | Admin Databricks |
| 5 | Exceção a R1 registrada no AGENTS.md | Eng. de Dados |
| 6 | `RAIZ_PROJETO/_reconcile/config/` criado e versionado | Eng. de Dados |
| 7 | Config gerada para os 4 mapeamentos confirmados do AGENTS.md | Eng. de Dados |
| 8 | Versão do Lakebridge fixada e registrada | Eng. de Dados |
| 9 | Piloto em `producao_det` com resultado conferido contra query manual | Eng. de Dados |

O item 9 não é formalidade. Rode a primeira reconciliação em paralelo com a query manual equivalente e compare os dois resultados — é assim que se descobre se as `transformations` estão corretas antes de confiar no dashboard.
