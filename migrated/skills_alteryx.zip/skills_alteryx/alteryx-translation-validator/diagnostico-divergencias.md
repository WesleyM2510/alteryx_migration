# Diagnóstico de Divergências — Sintoma → Tool Suspeita → Causa → Confirmação

## When to Use

Fase D. Quando a reconciliação (Fase C) acusa divergência, este catálogo converte o **sintoma** em lista de **tools suspeitas em ordem de probabilidade**, com a **query de confirmação** de cada hipótese. O objetivo final é sempre reportar: `tool_id=<n> (<plugin>) | notebook:célula | causa raiz | correção`.

## Princípios

1. **Fontes antes de transformações.** Se as fontes já divergem (Fase B), nenhuma hipótese de transformação vale.
2. **Mais a montante primeiro.** Uma causa raiz gera N sintomas a jusante — localizar o primeiro checkpoint divergente no DAG e ignorar os derivados até reexecutar.
3. **Confirmar antes de corrigir.** Toda hipótese fecha com uma query de confirmação; sem evidência, é palpite.
4. **Registrar tudo** com ToolID, mesmo hipóteses descartadas (evita retrabalho na próxima divergência).

## Árvore de decisão

```text
Erro de execução (exception)?           → §4
Contagem (Nível 1) bate?
  NÃO → fontes reconciliam (Fase B)?
          NÃO → causa na fonte / substituição 4.10 / período — não é tradução
          SIM → checkpoint walk → primeiro bloco divergente → §1 pela assinatura
  SIM → schema (Nível 2) bate?
          NÃO → schema walk → §2
          SIM → agregados (Nível 3) batem?
                  NÃO → §3 pela assinatura da coluna divergente
                  SIM → chaves/hash (Níveis 4-5) → §1.3 / §3 via normalização progressiva
```

---

## §1 — Volumetria

### 1.1 NEW > REF (linhas a mais)

| Assinatura | Suspeito nº 1 | Causa típica | Confirmação |
|---|---|---|---|
| Múltiplas linhas por chave de negócio | **Join** | Fan-out: chave não única no lado que deveria ser único | `GROUP BY chave HAVING COUNT(*) > 1` no lado direito (Q-FANOUT) |
| Duplicatas exatas (linha inteira repetida) | **Carga**, não tradução | Reexecução com append (estratégia de carga / R10) | Volumetria por `DATA_REF`: NEW com ~2× o período → duplicação de carga |
| Explosão multiplicativa (NEW ≈ \|L\|×\|R\|) | **Append Fields** / join sem chave | Cross join não intencional ou limite da config ignorado | Razão NEW/REF ≈ contagem do lado menor |
| Linhas multiplicadas proporcionais a delimitadores | **Text to Columns (rows)** | `explode` com tratamento diferente de vazio/null | Contar delimitadores por linha na origem |
| Branch T inflado | **Filter** | T implementado como `cond OR cond IS NULL` (null pertence ao F) | Contar nulls da coluna da condição |

### 1.2 NEW < REF (linhas a menos)

| Assinatura | Suspeito nº 1 | Causa típica | Confirmação |
|---|---|---|---|
| Matches de join perdidos | **Join** | Trailing space / case (origem In-DB, collation CI); tipos de chave divergentes com cast implícito | Anti-join (Q-ANTIJOIN); inspecionar chaves perdidas: `length(k) <> length(trim(k))`; reexecutar anti-join com `upper(trim(k))` — se zerar, é collation |
| Deduplicação indevida geral | **Union** | `UNION` do SQL (deduplica) no lugar de `UNION ALL` | Contar duplicatas exatas em REF (Q-DUPEXATA); grep `UNION` sem `ALL` |
| Dedup excessivo | **Unique** | Partição com campos a menos que a config | `COUNT DISTINCT` dos campos exatos da config vs contagem NEW |
| Nulls desaparecendo do branch F | **Filter** | `NOT(cond)` sem `IS NULL` | Contar nulls da coluna da condição — deve ≈ diferença |
| Período parcialmente vazio | **Parâmetro** | `'6'` vs `'06'` em `DATA_REF` | `SELECT DISTINCT DATA_REF` nos dois lados (Q-PERIODO) |
| Fonte "menor" que a original | **Substituição 4.10** | Equivalente no Lake carrega `WHERE` embutido (ex.: `CON_COD_SIS <> 80`) | Reconciliar fonte legada vs equivalente no período |
| Grupos ausentes no pivot | **Cross Tab** | Lista de valores fixada excluindo valores novos do período | `DISTINCT` da coluna pivotada no período |

### 1.3 Contagem bate, conjunto de chaves difere (troca 1:1)

| Assinatura | Suspeito | Causa | Confirmação |
|---|---|---|---|
| Anti-join devolve N chaves em cada sentido | **Unique / Sample / First-Last** | Retenção dependente de ordem: cada engine mantém uma linha diferente do grupo | Para chaves trocadas, listar todas as linhas do grupo na origem e conferir a coluna de ordem usada |
| Chaves diferem, amostragem aleatória no fluxo | **Random Sample** | Irreprodutível por natureza | Ressalva permanente; validar volumetria e distribuição apenas |

---

## §2 — Schema e tipo

Localização: **varredura de schema por checkpoint** (Fase D.4) — capturar `df.dtypes` após cada bloco anotado e reportar o ToolID do **primeiro** ponto em que o schema desvia do esperado.

| Sintoma | Suspeitos (em ordem) | Confirmação |
|---|---|---|
| Coluna ausente em NEW | Select (deselect indevido) · Cross Tab (valor não ocorreu no período de teste) · Union byName com coluna faltante | Schema walk; para Cross Tab, `DISTINCT` da coluna pivotada no período |
| Coluna extra em NEW | Select (deselect esquecido) · `Right_*` de join não removido quando o Alteryx removia | Schema walk + diff com schema de saída do .yxmd |
| Tipo divergente | Select (cast) · `Fixed Decimal` com p/s errados · inferência do Spark em literais/união por posição | Schema walk; conferir cast explícito no bloco apontado |
| Nome difere só por case/caractere | Sanitização do Cross Tab · rename não aplicado | Comparar listas com `lower()` para separar "só case" de "nome realmente outro" |

---

## §3 — Valores (contagem e chaves batem; conteúdo diverge)

| Assinatura | Suspeito nº 1 | Causa | Confirmação |
|---|---|---|---|
| Diferença pequena, sistemática, mesma direção, em coluna decimal | **Select / Fixed Decimal** | Truncamento (Alteryx) vs arredondamento (CAST) | Diff médio por linha ~ 10⁻ˢ; hash bate após normalização por `round` |
| `COUNT(col)` não-nulo difere **e** a soma difere na mesma coluna | **Formula / ToNumber** | Alteryx → 0 com warning; Spark cast → null | Listar valores não numéricos da coluna de origem |
| Só colunas de Multi-Row / Running Total / First-Last / Concat divergem | **Tools dependentes de ordem** | Sem chave determinística no `OVER (ORDER BY)` | Inspecionar o `OVER` do bloco; conferir estabilidade da chave de ordem |
| Strings diferem por case/espaços | **Data Cleansing / collation / upper-lower** | Limpeza aplicada ≠ checkboxes; comparação CI virou CS | Normalização progressiva: bate com `trim` → espaços; com `upper` → case |
| Datas ±1 dia ou hora deslocada (ex.: −3h) | **Timezone / máscara** | `current_timestamp` UTC vs hora local; `%Y` vs `yyyy` mal convertida | Comparar com timezone convertido; testar a máscara em amostra |
| Strings deslocadas em 1 caractere | **Formula / Substring** | Base 0 (Alteryx) vs base 1 (SQL) | Inspecionar `substring(col, pos, len)` do bloco |
| Valores "trocados" entre colunas do pivot | **Cross Tab** | Ordenação/sanitização de cabeçalhos divergente | Comparar cabeçalhos gerados vs saída Alteryx |
| Extração regex nula ou diferente | **RegEx** | Flavor Perl/Boost vs Java | Testar o padrão nos dois flavors com amostra real |
| `''` virou null (ou vice-versa) | **Data Cleansing / IsEmpty×IsNull** | Distinção `''`≠null perdida na tradução | Contar `col = ''` e `col IS NULL` nos dois lados (perfil Nível 3) |

---

## §4 — Erros de execução (o notebook falha)

| Mensagem (aproximada) | Causa provável | Correção |
|---|---|---|
| `PARSE_SYNTAX_ERROR` próximo de `-` | `dtlk-sandbox` sem backticks | Crases no catálogo |
| `PARSE_SYNTAX_ERROR` em valor de filtro | Parâmetro Python sem aspas no SQL | `'{args.get("pr_ano")}'` |
| `TABLE_OR_VIEW_NOT_FOUND` | Ordem do executor errada · `int_` ainda não gerada · view de bloco anterior não criada · substituição 4.10 para tabela inexistente | Conferir dependências no `_executor` e existência via `information_schema` |
| `UNRESOLVED_COLUMN` / column not found | Coluna suposta ≠ schema real (padrão dos "Erros Recorrentes") | Validar colunas via `information_schema.columns` (Q-SCHEMA) |
| `AMBIGUOUS_REFERENCE` | Join com colunas homônimas sem alias | Aliases + replicar renomeio `Right_*` |
| `CAST_INVALID_INPUT` / `NUMERIC_VALUE_OUT_OF_RANGE` / `DIVIDE_BY_ZERO` | Modo ANSI ativo; o Alteryx nunca lança | `try_cast` / `try_divide` / `NULLIF` conforme a fidelidade exigida — decisão registrada |
| Schema mismatch no save (`DELTA_FAILED_TO_MERGE_FIELDS` e similares) | Tipo/coluna difere da tabela Delta existente | Alinhar casts; conferir estratégia de carga e semântica do `sv.save()` |
| Duplicate column name | Colisão pós-sanitização do Cross Tab | Renomeio determinístico das colunas geradas |
| Widget/parâmetro não definido | `names` do notebook ≠ parâmetros do executor | Igualar nomes exatos (checklist da flow-validator) |

---

## Saída obrigatória do diagnóstico

Para cada divergência confirmada, uma linha no relatório com **todos** os campos:

```text
[ERRO|RESSALVA] <tabela> | <nível/sintoma> | tool_id=<n> (<plugin>) | <notebook:célula ou arquivo:linha>
       Causa raiz: <uma frase>
       Evidência: <resultado da query de confirmação>
       Correção sugerida: <ação, apontando a seção do checklist>
```

Sem ToolID identificável (bloco sem anotação `@alteryx`): reportar o bloco pelo notebook:célula, registrar a ausência da anotação como ERRO de rastreabilidade e abrir pendência.
