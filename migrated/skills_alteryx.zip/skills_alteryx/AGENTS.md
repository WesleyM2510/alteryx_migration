# AGENTS.md — Migração Alteryx → Databricks

Este projeto contém migrações de fluxos Alteryx (.yxmd) para notebooks Databricks.

## Princípios Obrigatórios

1. **Fidelidade total ao fluxo Alteryx** — transcrever a lógica exatamente como existe no .yxmd.
2. **Não criar regras que não existam** no fluxo original.
3. **Não otimizar regras** sem solicitação explícita do usuário.
4. **Utilizar Spark SQL** sempre que possível — `spark.sql(""".....""")`.
5. **Seguir obrigatoriamente o padrão de `_fluxo_modelo`** — analisar todos os `##comment:` existentes.
6. **Identificar e documentar a estratégia de carga** em célula comentada ao final de cada notebook.
7. **Identificar dependências entre fluxos** antes e após a migração.
8. **Utilizar lineage** para substituir leituras de bases legadas por tabelas já migradas quando aplicável.
9. **Tabelas intermediárias com prefixo `int_`** — formato: `int_<prefixo>__<nome>`.
10. **Não utilizar DDL de tabela ou view temporária em SQL** — nenhum `CREATE [OR REPLACE] [GLOBAL] TEMP[ORARY] VIEW`/`TABLE` dentro de `spark.sql()`. O registro de view de sessão é feito **pela API DataFrame**: `df.createOrReplaceTempView("<alias>")`, que é o padrão obrigatório do projeto (regra 4.03 do migrator). `createGlobalTempView` também é proibido.
11. **Um save por notebook** — cada `sv.save()` deve estar em notebook separado. Exceção: intermediárias simples (filtro/projeção) que geram 1 tabela final no mesmo notebook, desde que não sejam consumidas por outros notebooks.
14. **Documentar destino original na Célula 1** — imediatamente abaixo de `table = '...'`, incluir comentário `# DESTINO ALTERYX:` com o caminho COMPLETO de onde o Alteryx salvava o resultado. Para arquivos: `# DESTINO ALTERYX: \\servidor\share\pasta\arquivo.xlsx|||Guia`. Para bancos: `# DESTINO ALTERYX: servidor.instancia.database.tabela`. Copiar exatamente da tag `<File>` do DbFileOutput no .yxmd.
12. **Documentar fontes de origem** — toda fonte na Célula 5 DEVE conter `# ORIGEM ALTERYX:`, `# TIPO:` e `# STATUS LAKE:`. Após migração, registrar cada fonte na tabela Delta ``dtlk-sandbox`.micracao_alteryx.fontes_origem` (ÚNICO controle centralizado — arquivo `fontes_origem.md` descontinuado). Dashboard: "Fontes de Origem — Migração Alteryx". Sempre que mencionar fonte + lake na mesma conversa → atualizar a tabela.
13. **Critério de `existe_lake`: "Consigo acessar via Databricks?"** — SIM = qualquer SELECT funcional no Databricks (Delta nativo, Lakehouse Federation, Trino/Presto, catálogo externo). NÃO = fonte sem acesso via Databricks. VERIFICAR = não determinado. **PARCIAL descontinuado.** NUNCA marcar NÃO sem verificação; nunca inserir sem checar duplicata de `fluxo` + `tool_id`.

> **Regra canônica de fontes:** schema da tabela, procedimentos de verificação, templates de INSERT/UPDATE e checklist vivem em `skills/_shared/fontes-origem.md`. As regras 12 e 13 acima são o princípio; o detalhe operacional mora lá e **só lá**. Alterar critério ou schema = editar aquele arquivo, não este.

## Regras Invioláveis (R1-R10)

Aplicam-se a toda execução de migração. Violação de qualquer regra = parar e corrigir.

- **R1 — Escopo de escrita**: todo caminho é absoluto e começa por `RAIZ_PROJETO`. Destino fora dele (home do usuário, `/tmp`, diretório corrente) → abortar e reportar, nunca escrever.
- **R2 — Scripts são FILES**: nada de `# Databricks notebook source` na linha 1, `# COMMAND ----------`, comandos mágicos ou `dbutils` em `scripts/`. Após gravar, verificar `object_type == FILE`.
- **R3 — Nada é "criado" sem evidência**: reler cada arquivo do disco e reportar caminho, bytes, linhas e trecho inicial/final. 0 bytes ou `TODO`/`pass` no lugar da lógica = falha, refazer.
- **R4 — Notebook não chama script**: mesma lógica em dois formatos, zero dependência de execução entre eles. Proibido `%run`/`import`/`dbutils.notebook.run` de `notebooks/` para `scripts/`.
- **R5 — Zero invenção**: o que não mapear 1:1 do XML vai para `PENDENCIAS.md` com ToolID, motivo e pergunta em aberto.
- **R6 — Um fluxo por vez**: Fases 1→7 completas + checkpoint antes do próximo fluxo.
- **R7 — Ler antes de escrever**: Fase 0 (absorver padrões de referência) é bloqueante.
- **R8 — Desabilitado é ignorado, com herança recursiva** de containers; registrar o que foi ignorado.
- **R9 — Grafo vem de `<Connections>`**, nunca do layout do canvas.
- **R10 — Idempotência**: reexecutar sobrescreve, não duplica.

## Proibições Absolutas

- Qualquer DDL de temporária dentro de `spark.sql()`, incluindo as variações de sintaxe do Spark:
  `CREATE TEMP TABLE`, `CREATE TEMPORARY TABLE`, `CREATE TEMP VIEW`, `CREATE TEMPORARY VIEW`,
  `CREATE OR REPLACE TEMP VIEW`, `CREATE OR REPLACE TEMPORARY VIEW`, `CREATE GLOBAL TEMP[ORARY] VIEW`
- `df.createGlobalTempView(...)` (a forma de sessão `createOrReplaceTempView` é **permitida e obrigatória** — ver regra 10)
- Inventar colunas, joins ou filtros não existentes no Alteryx original
- Alterar nomes de parâmetros entre notebooks e executores
- Quebrar o fluxo artificialmente (ex: 001_filter, 002_sort, 003_join)
- Múltiplos `sv.save()` no mesmo notebook para tabelas independentes (cada output = 1 notebook)

## Rastreabilidade por ToolID

Todo bloco de lógica — no script e no notebook — deve carregar a anotação grepável apontando as tools de origem:

```python
# @alteryx tool_id=42 plugin=AlteryxBasePluginsGui.Filter.Filter caption="Filtra vigentes"
# regra: [Status] = "A" AND !IsNull([DataFim])
df_vigentes = spark.sql("""
    SELECT *  -- @alteryx tool_id=42,43 | Filter + Select
    FROM clientes_int
    WHERE status = 'A' AND data_fim IS NOT NULL
""")
```

A matriz de cobertura (`mapa_de_regras.md`) exige `tools ativas == linhas mapeadas`, cada uma com referência real de arquivo:linha e célula de notebook.

## Tecnologia

**Prioridade 1:** Spark SQL via `spark.sql("""...""")`
**Prioridade 2:** DataFrame API — apenas quando Spark SQL não for adequado

## Caminhos Fixos do Projeto

| Referência | Caminho |
|---|---|
| Modelo de notebook | `/Workspace/Shared/Engineering/Migracao_Alteryx/_fluxo_modelo` |
| Libs (setup) | `/Workspace/Shared/Engineering/Migracao_Alteryx/_libs/_setup` |
| Libs (executor) | `/Shared/Engineering/Migracao_Alteryx/_libs/_setup_executor` |
| Catálogo destino | `dtlk-sandbox`.`micracao_alteryx` |
| Função de save | `sv.save(df=df, tabela=table)` |
| Função de widgets | `utl.widgets_start(names=names)` |

## Parâmetros

Não existem parâmetros padrão fixos. Os parâmetros devem ser **identificados a partir do fluxo Alteryx** durante a análise do .yxmd (variáveis de entrada, filtros temporais, conexões parametrizadas). Cada fluxo define seus próprios parâmetros conforme necessidade.

Padrão de nomenclatura: `pr_<nome>` (ex: `pr_ano`, `pr_mes`, `pr_versao`)

## Nomenclatura

### Tabelas intermediárias
```
int_<prefixo>__<nome_tabela>
```
Exemplos: `int_financeiro__clientes`, `int_financeiro__receitas`

### Tabelas finais
```
<prefixo>__<nome_tabela>
```
Exemplos: `financeiro__fechamento`, `financeiro__resultado`

### Notebooks
```
<sequencia>_<nome_da_tabela_do_save>
```
Exemplos: `001_int_financeiro__clientes`, `002_int_financeiro__receitas`, `003_financeiro__resultado`

### Regra de quebra de notebooks
- Criar notebooks separados **apenas** quando existir necessidade de persistência reutilizada por notebook posterior.
- **Correto:** `001_int_financeiro__calculo` -> `002_int_financeiro__deducoes` -> `003_financeiro__fechamento` (003 depende de 001 e 002)
- **Incorreto:** `001_filter` -> `002_formula` -> `003_sort` -> `004_join` (sem persistência intermediária necessária)

## Estrutura de Diretórios

```
/Workspace/Shared/Engineering/Migracao_Alteryx/
+-- AGENTS.md                          <- este arquivo (contexto central)
+-- _fluxo_modelo/                     <- modelo obrigatório de estrutura
+-- _libs/                             <- bibliotecas compartilhadas
|   +-- _setup                         <- imports e utilitários dos notebooks
|   +-- _setup_executor                <- lógica de execução sequencial
+-- skills/
|   +-- alteryx-flow-migrator/         <- conversão .yxmd -> notebooks
|   |   +-- SKILL.md
|   |   +-- processo.md               <- fases 0-8 detalhadas
|   |   +-- semantica-alteryx-spark.md <- armadilhas de tradução tool-a-tool
|   +-- alteryx-flow-validator/        <- auditoria pós-migração
|   |   +-- SKILL.md
|   +-- alteryx-lineage-analyzer/      <- mapeamento de dependências
|   |   +-- SKILL.md
|   +-- alteryx-master-executor/       <- criação/manutenção _executor_master
|       +-- SKILL.md
+-- <dominio>/                         <- ex: Financeiro, Fiscal, RH
    +-- <Fluxo>/
    |   +-- <fluxo>.yxmd              <- arquivo Alteryx original
    |   +-- notebooks/                <- notebooks migrados
    |   +-- _executor                 <- executor do fluxo
    +-- _executor_master              <- executor consolidado do domínio
```

## Servidor SQL Server Legado

**Servidor fonte:** `swap1478_pl.dbo.*`
**Destino no Lake:** `dtlk-sandbox.micracao_alteryx.*`

### Mapeamentos confirmados

| SQL Server | Lake |
|---|---|
| `swap1478_pl.dbo.producao_det_cartoes` | `dtlk-sandbox.micracao_alteryx.planejamento__producao_det_cartoes` |
| `swap1478_pl.dbo.cadastro_subcanais` | `dtlk-sandbox.micracao_alteryx.planejamento__cadastro_subcanais` |
| `swap1478_pl.dbo.conductor_resultado_det` | `dtlk-sandbox.micracao_alteryx.int_planejamento__conductor_resultado_det` |
| `swap1478_pl.dbo.producao_det WHERE CON_COD_SIS <> 80` | `dtlk-sandbox.micracao_alteryx.int_planejamento__producao_emprestimos` |

### Mapeamento de colunas: producao_det -> int_planejamento__producao_emprestimos

| SQL Server | Lake |
|---|---|
| `cod_contrato` | `COD_CONTRATO` |
| `pro_dsc_gpr` | `FAMILIA_PRODUTO` |
| `vl` | `PDU_VLR_LIB` |
| `vlr_con` | `PDU_VLR_CON` |
| `taxa_aa` | `TAXA_ANUAL` |
| `pro_cod_cla` | `CON_COD_PRO` |
| `CON_COD_SIS` | nao existe no lake (NULL) |
| `DATA_REF` | `CONCAT(ano, LPAD(mes,2,'0'))` |

### Tabelas ainda no SQL Server (sem equivalente no Lake)

`rentabilidade_cartao`, `comissoes_ifrs`, `cadastro_contas`, `cadastro_produto_operacional`,
`cadastro_hie_produtos`, `funding_produto_taxa`, `funding_hist_taxas`, `bmg_card_tomb_parc`,
`t_parcelamentofatura`, `t_conta`, `dwd_cartao_conta_atual`, `cadastro_regras_canais_geral`, `cadastro_fontes`

## Padroes de Filtro Temporal

- Tabelas transacionais: `DATA_REF = 'YYYYMM'` (campo string)
- Tabelas com colunas ANO/MES/VERSAO: `interchange`, `comissoes_ifrs`
- **Parametros Python sempre com aspas:** `ANO = '{args.get("pr_ano")}'`
  - Sem aspas -> `PARSE_SYNTAX_ERROR`

## Schema swap1478_pl.dbo.producao_det

Colunas: `COD_CONTRATO`, `FAMILIA_PRODUTO`, `TABELA`, `PDU_QTD_PAR`, `DATA_REF`,
`COD_SUBCANAL`, `CON_DAT`, `CON_COD_PRO`, `CON_COD_SIS` (string), `COD_LOJA`,
`TAXA_ANUAL`, `PDU_VLR_LIB`, `PDU_VLR_CON`, `TIPO`, `BANCO_DEBITO`

## Erros Recorrentes nas Migracoes

- Joins via `COD_PROD_OPER` em `producao_det` -> coluna nao existe; equivalente e `CON_COD_PRO`
- Filtros `CON_COD_SIS = 80` adicionados onde nao existem no Alteryx
- Colunas `COD_PROD_OPER`, `DESC_PRODUTO`, `COD_EMPRESA`, `NUM_CONTRATO` em queries de `producao_det` (nao existem)
- `r.NUM_CONTRATO` em `rentabilidade_cartao` -> correto e `r.CTA_NRO_INT`
- `planejamento__producao_det_cartoes` com filtro ANO/MES -> correto e `DATA_REF = 'YYYYMM'`

## Notebooks por Fluxo: Financeiro/Planejamento

| Fluxo Alteryx | Notebook | ID |
|---|---|---|
| `02_GERA_PRODUCAO_CARTOES` | `001_planejamento__producao_cartoes` | 827293016969437 |
| `03_CARREGA_PRODUCAO_DET` | `001_planejamento__producao_det_cartoes` | 827293016969442 |
| `07_Interchange_Oracle` | `001_planejamento__interchange` | 827293016969477 |
| `07_MOTOR_SAQUES` | `001_planejamento__base_motor_saques_cartoes` | 4456931767143816 |
| `08_MOTOR_SAQUES_ETAPA2` | `001_planejamento__motor_cartoes_saques` | 4456931767143820 |
| `09_MOTOR_PARCELAMENTO_ETAPA1` | `001_planejamento__base_motor_parcelamento_fatura_etapa1` | 4456931767143828 |
| `10_MOTOR_PARCELAMENTO_ETAPA2` | `001_planejamento__base_motor_parcelamento_fatura_etapa2` | 4456931767143831 |

## Workflow Recomendado

```
1. alteryx-lineage-analyzer          -> mapear dependencias ANTES da migracao
2. alteryx-flow-migrator             -> converter .yxmd em notebooks
3. alteryx-flow-validator            -> auditar a migracao
4. alteryx-translation-validator     -> auditar a equivalencia de dados
5. alteryx-master-executor           -> criar/atualizar _executor_master
```

## Skills do Projeto

| Skill | Responsabilidade |
|---|---|
| `alteryx-flow-migrator` | Converter .yxmd em notebooks Databricks |
| `alteryx-flow-validator` | Auditar e validar migracoes realizadas |
| `alteryx-translation-validator` | Validar equivalência semântica e de dados (reconciliação + diagnóstico por ToolID) |
| `alteryx-lineage-analyzer` | Mapear dependencias entre fluxos e tabelas |
| `alteryx-master-executor` | Criar/manter o notebook _executor_master |

**Caminho base das skills:**
`/Workspace/Shared/Engineering/Migracao_Alteryx/skills/<skill-name>/SKILL.md`

**Como carregar uma skill do projeto:**
```
readAssetById(
  assetType="file",
  assetId="/Workspace/Shared/Engineering/Migracao_Alteryx/skills/<skill-name>/SKILL.md"
)
```
