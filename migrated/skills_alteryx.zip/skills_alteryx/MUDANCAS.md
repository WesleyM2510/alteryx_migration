# Mudanças nas Skills — Consolidado

Pacote **completo**: substitui toda a árvore `skills/` mais o `AGENTS.md`. Descompacte sobre
`/Workspace/Shared/Engineering/Migracao_Alteryx/` e sobrescreva tudo. Não é preciso rastrear
deltas de rodadas anteriores — este pacote é o estado final.

## Estrutura nova

Duas coisas que não existiam antes:

- **`skills/_shared/`** — pasta irmã das skills, com as três regras canônicas
  (`fontes-origem.md`, `loop-feedback.md`, `fluxo-de-skills.md`)
- **`skills/alteryx-execution-monitor/`** — skill nova de monitoramento de execução mensal

## Índice das rodadas

| Rodada | O que fez |
|---|---|
| P0 | Regra de `fontes_origem` centralizada; 7 referências a `PARCIAL` corrigidas |
| P1 | Ambiguidade do TEMP VIEW resolvida; buraco de detecção (`TEMPORARY`) fechado |
| P2 | `flow-validator` reescrita: 35→64 checks, 6 fases com gate, veredito, `[AMBIGUO]` |
| Lakebridge | Reconcile integrado à `translation-validator` (Fase B) |
| Monitor | Skill nova para a execução mensal recorrente |
| Inativas | `flow-migrator` e `lineage-analyzer` marcadas (não deletadas) |
| Loop | Captura de descobertas centralizada em `_shared/loop-feedback.md` |
| P5 | Frontmatter nativo nas 7 skills; mapa de encadeamento |

---

## P0 — Regra de fontes em um lugar só

`skills/_shared/fontes-origem.md` (novo) é a fonte única: critério de `existe_lake`, schema,
verificação, INSERT, UPDATE, checklist. As quatro cópias por extenso viraram ponteiro
`../_shared/fontes-origem.md`. Alterar o critério passou de nove edições coordenadas para uma.

`PARCIAL` foi descontinuado — sete referências obsoletas corrigidas em migrator, lineage e
flow-validator. Toda menção remanescente é aviso de descontinuação ou check que o reprova.

## P1 — TEMP VIEW

Regra 10 proíbe DDL de temporária em SQL; `df.createOrReplaceTempView()` é permitido e
obrigatório. A leitura escolhida é a única que não invalida os notebooks já migrados.

Buraco de detecção fechado: o check antigo procurava `TEMP`, mas a palavra-chave canônica do
Spark é `TEMPORARY` — a forma mais comum (`CREATE OR REPLACE TEMPORARY VIEW`) passava batido.

## P2 — `flow-validator` elevada

O validador auditava só notebooks; a migração produz `scripts/`, inventários, mapa de regras,
`_executor`. R2, R3, R4, R5, R8, R9, R10 não tinham check. Reescrito em 6 fases (A–F) com gate
nas duas primeiras, veredito por fluxo, evidência obrigatória, e o nível `[AMBIGUO]` para
quando o próprio padrão se contradiz. 3 contradições do `processo.md` corrigidas na fonte.

Novo: `skills/alteryx-flow-validator/checklist-estrutural.md`.

## Lakebridge Reconcile

Integrado à `translation-validator` na Fase B (reconciliação de fonte legada `swap1478_pl`).
A Fase C permanece manual — os 5 níveis medem o que o Reconcile não mede. Modos `row`/`data`/
`all` só com `transformations` declaradas, porque calculam hash no lado da origem.

Novo: `skills/alteryx-translation-validator/reconcile-lakebridge.md`.

## Monitor de execução (skill nova)

`skills/alteryx-execution-monitor/` — vigia a carga mensal que o `_executor_master` roda em
produção. Compara período atual contra o histórico da própria tabela: month-over-month, média
móvel, valor de negócio, frescor. Detecta carga parcial, reexecução com append, fonte que
sumiu, join quebrado. Notifica, não bloqueia. É o único item da suíte que endereça risco
corrente, não dívida de migração.

Precisa de duas tabelas de apoio (`monitor_config`, `monitor_historico`) — schema sugerido no
SKILL.md.

## Skills inativas (item 4)

Marcadas no topo, **conteúdo preservado**:

- `flow-migrator` — ⛔ inativa; vira referência do padrão que a `flow-validator` consulta
- `lineage-analyzer` — ⚠️ parcial; só o modo "após migração" sobrevive

## Loop de feedback (item 6)

`skills/_shared/loop-feedback.md` (novo) centraliza o roteamento de descobertas: tabela de
destino por tipo, critério de promoção (reproduzível + verificável + geral, segunda
ocorrência), triagem por dono humano, poda do AGENTS.md. As cinco skills ativas apontam para
ele no encerramento.

**Ponto em aberto para o projeto:** quem é o dono da triagem. Até haver um, o loop registra
propostas mas não promove nada ao AGENTS.md automaticamente — seguro, mas represa as
propostas.

## P5 — Forma nativa

**Achado central:** nenhuma das skills tinha frontmatter. Uma skill nativa dispara pela
`description` no bloco `---`; sem ele, o carregamento automático não acontece — por isso o
AGENTS.md usava `readAssetById()` com caminho, como contorno.

Adicionado frontmatter (`name` + `description`) às 7 skills, com a `description` escrita para
disparar por gatilho concreto, não por definição genérica. As skills inativas trazem o aviso
`[INATIVA]` logo no início da `description`.

Novo: `skills/_shared/fluxo-de-skills.md` — mapa único de qual skill roda quando, para que
carregar uma skill isolada não esconda a cadeia.

---

## Verificações pendentes (não bloqueiam a subida)

Herdadas das rodadas, valem uma passada sobre o parque real:

1. **Frontmatter no editor** — confirmar que as skills agora disparam por `description`. Se o
   editor exige formato próprio diferente do `---` YAML, ajustar.
2. **`TEMPORARY` em produção** — o check antigo não pegava; rodar o grep novo sobre os
   notebooks migrados:
   ```bash
   grep -rniE "CREATE[[:space:]]+(OR[[:space:]]+REPLACE[[:space:]]+)?(GLOBAL[[:space:]]+)?TEMP(ORARY)?[[:space:]]+(VIEW|TABLE)" notebooks/
   ```
3. **`PARCIAL` nos dados** — reclassificar registros já gravados:
   ```sql
   SELECT fluxo, tool_id, tabela_sql FROM `dtlk-sandbox`.micracao_alteryx.fontes_origem
   WHERE existe_lake = 'PARCIAL';
   ```
4. **Fases A e B da flow-validator** — nunca rodaram sobre o parque; passar em um fluxo
   representativo para medir dívida.
5. **Dono da triagem do loop** — decisão de processo, destrava o item 6 por completo.

## Nada mais em aberto na fila

P0, P1, P2, monitor, inativação, loop e P5 estão fechados. Não sobrou item de backlog além das
verificações acima, que são de campo (dependem do workspace e do time), não de escrita.
